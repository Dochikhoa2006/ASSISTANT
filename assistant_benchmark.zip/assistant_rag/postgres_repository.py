from __future__ import annotations
import os
import json
import uuid
from contextlib import contextmanager
from typing import Any, Iterator, Optional
from datetime import datetime, timezone

from sqlalchemy import create_engine, select, insert, update, delete, and_, or_, func, case
from sqlalchemy.dialects.postgresql import insert as postgresql_insert
from sqlalchemy.dialects.sqlite import insert as sqlite_insert
from sqlalchemy.engine import Engine, Connection

from .repository import AssistantRepository
from .contracts import *
from .postgres_schema import *
from .database import (
    content_hash,
    knowledge_chunk_content_hash,
    require_stable_user_id,
)
from .recurrence import calculate_next_fire_time
from .lifecycle import is_artifact_downloadable, is_indexable_conversation_hop, is_indexable_knowledge_chunk
from .metrics import GLOBAL_METRICS
from .conversation_embedding import (
    conversation_hop_embedding_metadata,
    conversation_hop_semantic_payload,
    serialize_conversation_hop,
)
from .errors import (
    KnowledgeConflictError,
    ReminderConflictError,
    RepositoryConflictError,
    RepositoryValidationError,
)

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def new_id() -> str:
    return uuid.uuid4().hex


def _optional_datetime(value: Any) -> datetime | None:
    if value in (None, ""):
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)

class PostgresRepository(AssistantRepository):
    def __init__(self, engine: Engine):
        self.engine = engine
        self._local_conn: Connection | None = None

    @classmethod
    def create(cls, url: str, pool_size: int = 10, max_overflow: int = 20) -> 'PostgresRepository':
        kwargs = {}
        if not url.startswith("sqlite"):
            kwargs = {"pool_size": pool_size, "max_overflow": max_overflow}
        engine = create_engine(url, **kwargs)
        return cls(engine)

    def close(self) -> None:
        self.engine.dispose()

    @classmethod
    def in_memory(cls) -> 'SQLiteRepository':
        raise NotImplementedError("Use SQLiteRepository for in-memory databases")

    @classmethod
    def persistent(cls, database_path: str, *, enable_wal: bool, busy_timeout_ms: int) -> 'SQLiteRepository':
        raise NotImplementedError("Use SQLiteRepository for persistent SQLite databases")

    def initialize_schema(self) -> None:
        metadata.create_all(self.engine)

    @contextmanager
    def transaction(self) -> Iterator[Connection]:
        if self._local_conn is not None:
            with self._local_conn.begin_nested():
                yield self._local_conn
        else:
            with self.engine.begin() as conn:
                yield conn

    def table_count(self, table_name: str) -> int:
        table = metadata.tables[table_name]
        with self.engine.connect() as conn:
            return conn.execute(select(func.count()).select_from(table)).scalar() or 0

    def ensure_topic(
        self,
        cursor: Connection,
        *,
        user_id: str,
        title: str,
        topic_summary: str = "",
        state_summary: str = "",
        entities: dict[str, Any] | None = None,
    ) -> str:
        stmt = select(conversation_topics.c.topic_id).where(
            and_(
                conversation_topics.c.user_id == user_id,
                conversation_topics.c.title == title,
                conversation_topics.c.status == 'active'
            )
        ).order_by(conversation_topics.c.updated_at.desc()).limit(1)
        
        row = cursor.execute(stmt).fetchone()
        if row:
            return str(row[0])

        return self.create_topic(
            cursor,
            user_id=user_id,
            title=title,
            topic_summary=topic_summary,
            state_summary=state_summary,
            entities=entities,
        )

    def create_topic(
        self,
        cursor: Connection,
        *,
        user_id: str,
        title: str,
        topic_summary: str = "",
        state_summary: str = "",
        entities: dict[str, Any] | None = None,
    ) -> str:
        """Create a fresh active topic even when another title matches."""

        topic_id = new_id()
        timestamp = now_iso()
        cursor.execute(
            insert(conversation_topics).values(
                topic_id=topic_id,
                user_id=user_id,
                title=title,
                topic_summary=topic_summary,
                state_summary=state_summary,
                entities_json=json.dumps(entities or {}),
                last_hop_id=None,
                status='active',
                created_at=timestamp,
                updated_at=timestamp,
                version=1
            )
        )
        return topic_id

    def append_conversation_hop(
        self,
        cursor: Connection,
        *,
        topic_id: str,
        user_id: str,
        intent: str,
        raw_user_query: str,
        rewritten_user_query: str,
        raw_response: str,
        response_type: str,
        supporting_questions: list[str | dict[str, Any]] | None = None,
        parent_hop_id: str | None = None,
        branch_id: str | None = None,
        entities: dict[str, Any] | None = None,
        state_summary: str = "",
        hop_id: str | None = None,
    ) -> HopWrite:
        stmt = select(conversation_topics.c.last_hop_id).where(
            and_(
                conversation_topics.c.topic_id == topic_id,
                conversation_topics.c.user_id == user_id,
                conversation_topics.c.status == 'active'
            )
        ).with_for_update()
        row = cursor.execute(stmt).fetchone()
        if not row:
            raise ValueError("Active conversation topic not found for user")

        actual_hop_id = hop_id or new_id()
        topic_head_id = str(row[0]) if row[0] is not None else None
        explicit_parent = parent_hop_id is not None
        reference_hop_id = parent_hop_id if explicit_parent else topic_head_id
        reference_hop: dict[str, Any] | None = None
        if reference_hop_id:
            reference_hop = self._require_owned_conversation_hop(
                cursor,
                user_id=user_id,
                hop_id=reference_hop_id,
                topic_id=topic_id,
                require_active_topic=True,
            )

        previous_hop_id = reference_hop_id
        root_hop_id = self._resolve_root_hop(
            cursor,
            reference_hop_id=reference_hop_id,
            user_id=user_id,
            topic_id=topic_id,
        )
        depth_from_root = self._resolve_depth(
            cursor,
            reference_hop_id=reference_hop_id,
            user_id=user_id,
            topic_id=topic_id,
        )

        reference_branch_id = (
            str(reference_hop.get("branch_id") or "")
            if reference_hop is not None
            else ""
        ) or root_hop_id or reference_hop_id or actual_hop_id
        parent_has_branch_child = False
        if explicit_parent and reference_hop is not None:
            parent_has_branch_child = bool(
                cursor.execute(
                    select(conversation_hops.c.hop_id)
                    .where(
                        and_(
                            conversation_hops.c.user_id == user_id,
                            conversation_hops.c.topic_id == topic_id,
                            func.coalesce(
                                conversation_hops.c.branch_id,
                                conversation_hops.c.root_hop_id,
                                conversation_hops.c.hop_id,
                            )
                            == reference_branch_id,
                            conversation_hops.c.previous_hop_id
                            == reference_hop_id,
                        )
                    )
                    .limit(1)
                ).fetchone()
            )
        if not reference_hop:
            effective_branch_id = branch_id or actual_hop_id
        elif parent_has_branch_child:
            if branch_id:
                reused_branch = cursor.execute(
                    select(conversation_hops.c.hop_id)
                    .where(
                        and_(
                            conversation_hops.c.user_id == user_id,
                            conversation_hops.c.topic_id == topic_id,
                            conversation_hops.c.branch_id == branch_id,
                        )
                    )
                    .limit(1)
                ).fetchone()
                if reused_branch:
                    raise ValueError(
                        "Resuming an older conversation hop requires a new branch"
                    )
            effective_branch_id = branch_id or actual_hop_id
        else:
            if branch_id and branch_id != reference_branch_id:
                raise ValueError("Conversation branch does not match selected hop")
            effective_branch_id = reference_branch_id
        timestamp = now_iso()
        
        outbox_job_id = self.insert_outbox_job(
            cursor,
            entity_type=OutboxEntityType.CONVERSATION_HOP,
            entity_id=actual_hop_id,
            operation=OutboxOperation.UPSERT,
        )
        
        cursor.execute(
            insert(conversation_hops).values(
                hop_id=actual_hop_id,
                user_id=user_id,
                topic_id=topic_id,
                intent=intent,
                raw_user_query=raw_user_query,
                rewritten_user_query=rewritten_user_query,
                raw_response=raw_response,
                response_type=response_type,
                supporting_questions_json=json.dumps(supporting_questions or []),
                previous_hop_id=previous_hop_id,
                parent_hop_id=parent_hop_id,
                root_hop_id=root_hop_id,
                branch_id=effective_branch_id,
                depth_from_root=depth_from_root,
                entities_json=json.dumps(entities or {}),
                outbox_job_id=outbox_job_id,
                created_at=timestamp
            )
        )
        
        topic_update = cursor.execute(
            update(conversation_topics).where(
                and_(
                    conversation_topics.c.topic_id == topic_id,
                    conversation_topics.c.user_id == user_id,
                    conversation_topics.c.status == "active",
                )
            ).values(
                last_hop_id=actual_hop_id,
                state_summary=state_summary,
                updated_at=timestamp,
                version=conversation_topics.c.version + 1
            )
        )
        if topic_update.rowcount != 1:
            raise ValueError("Active conversation topic could not be updated")
        
        return HopWrite(
            topic_id=topic_id,
            hop_id=actual_hop_id,
            previous_hop_id=previous_hop_id,
            outbox_job_id=outbox_job_id
        )

    def merge_conversation_hop_entities(
        self,
        cursor: Connection,
        *,
        user_id: str,
        hop_id: str,
        entities: dict[str, Any],
    ) -> None:
        row = cursor.execute(
            select(conversation_hops.c.entities_json).where(
                and_(
                    conversation_hops.c.hop_id == hop_id,
                    conversation_hops.c.user_id == user_id,
                )
            )
        ).fetchone()
        if not row:
            raise ValueError("Conversation hop not found for user")
        try:
            current = json.loads(str(row[0] or "{}"))
        except (TypeError, ValueError, json.JSONDecodeError):
            current = {}
        if not isinstance(current, dict):
            current = {}
        current.update(entities)
        result = cursor.execute(
            update(conversation_hops)
            .where(
                and_(
                    conversation_hops.c.hop_id == hop_id,
                    conversation_hops.c.user_id == user_id,
                )
            )
            .values(entities_json=json.dumps(current))
        )
        if result.rowcount != 1:
            raise ValueError("Conversation hop entities could not be updated")

    def get_conversation_hop(self, *, user_id: str, hop_id: str) -> dict[str, Any]:
        with self.engine.connect() as conn:
            return self._require_owned_conversation_hop(
                conn,
                user_id=user_id,
                hop_id=hop_id,
            )

    def claim_conversation_scope(
        self,
        *,
        user_id: str,
        hop_id: str,
        conversation_id: str,
    ) -> bool:
        """Atomically bind an unscoped legacy hop and its active topic."""

        def entities(value: Any) -> dict[str, Any]:
            try:
                parsed = value if isinstance(value, dict) else json.loads(str(value or "{}"))
            except (TypeError, ValueError, json.JSONDecodeError):
                parsed = {}
            return dict(parsed) if isinstance(parsed, dict) else {}

        with self.transaction() as cursor:
            row = self._require_owned_conversation_hop(
                cursor,
                user_id=user_id,
                hop_id=hop_id,
                require_active_topic=True,
                for_update=True,
            )
            hop_entities = entities(row.get("entities_json"))
            topic_entities = entities(row.get("topic_entities_json"))
            existing = str(
                hop_entities.get("conversation_id")
                or topic_entities.get("conversation_id")
                or ""
            ).strip()
            if existing and existing != conversation_id:
                return False
            hop_entities["conversation_id"] = conversation_id
            topic_entities["conversation_id"] = conversation_id
            cursor.execute(
                update(conversation_hops)
                .where(
                    and_(
                        conversation_hops.c.hop_id == hop_id,
                        conversation_hops.c.user_id == user_id,
                    )
                )
                .values(entities_json=json.dumps(hop_entities))
            )
            result = cursor.execute(
                update(conversation_topics)
                .where(
                    and_(
                        conversation_topics.c.topic_id == row["topic_id"],
                        conversation_topics.c.user_id == user_id,
                        conversation_topics.c.status == "active",
                    )
                )
                .values(entities_json=json.dumps(topic_entities))
            )
            return result.rowcount == 1

    def list_conversations(
        self,
        *,
        user_id: str,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """List user-owned durable UI conversation cursors."""

        with self.engine.connect() as conn:
            topics = conn.execute(
                select(conversation_topics)
                .where(
                    and_(
                        conversation_topics.c.user_id == user_id,
                        conversation_topics.c.status == "active",
                    )
                )
                .order_by(conversation_topics.c.updated_at.desc())
            ).fetchall()
            conversations: list[dict[str, Any]] = []
            seen: set[str] = set()
            for topic_row in topics:
                topic = dict(topic_row._mapping)

                def decode(value: Any) -> dict[str, Any]:
                    try:
                        parsed = value if isinstance(value, dict) else json.loads(str(value or "{}"))
                    except (TypeError, ValueError, json.JSONDecodeError):
                        parsed = {}
                    return dict(parsed) if isinstance(parsed, dict) else {}

                conversation_id = str(
                    decode(topic.get("entities_json")).get("conversation_id") or ""
                ).strip()
                hop_rows = conn.execute(
                    select(conversation_hops)
                    .where(
                        and_(
                            conversation_hops.c.user_id == user_id,
                            conversation_hops.c.topic_id == topic["topic_id"],
                        )
                    )
                    .order_by(conversation_hops.c.created_at.desc())
                ).fetchall()
                hops = [dict(row._mapping) for row in hop_rows]
                if not conversation_id:
                    for hop in hops:
                        conversation_id = str(
                            decode(hop.get("entities_json")).get("conversation_id")
                            or ""
                        ).strip()
                        if conversation_id:
                            break
                if not conversation_id or conversation_id in seen:
                    continue
                seen.add(conversation_id)
                latest = next(
                    (
                        hop
                        for hop in hops
                        if str(hop.get("hop_id"))
                        == str(topic.get("last_hop_id"))
                    ),
                    None,
                )
                latest_query = str(latest.get("raw_user_query") or "") if latest else ""
                latest_response = str(latest.get("raw_response") or "") if latest else ""
                if latest:
                    latest_response = str(
                        decode(latest.get("entities_json")).get("final_chat_text")
                        or latest_response
                    )
                conversations.append(
                    {
                        "conversation_id": conversation_id,
                        "topic_id": str(topic["topic_id"]),
                        "title": str(topic.get("title") or latest_query or "Conversation"),
                        "summary": str(
                            topic.get("topic_summary") or latest_response or latest_query
                        )[:240],
                        "created_at": str(topic.get("created_at") or ""),
                        "updated_at": str(topic.get("updated_at") or ""),
                        "latest_hop_id": (
                            str(topic["last_hop_id"])
                            if topic.get("last_hop_id")
                            else None
                        ),
                    }
                )
                if len(conversations) >= max(1, int(limit)):
                    break
        return conversations

    def load_conversation(
        self,
        *,
        user_id: str,
        conversation_id: str,
    ) -> dict[str, Any]:
        """Load the latest branch lineage and exact stored transcript."""

        summary = next(
            (
                item
                for item in self.list_conversations(user_id=user_id, limit=1000)
                if item["conversation_id"] == conversation_id
            ),
            None,
        )
        if summary is None:
            return {}
        with self.engine.connect() as conn:
            rows = conn.execute(
                select(conversation_hops).where(
                    and_(
                        conversation_hops.c.user_id == user_id,
                        conversation_hops.c.topic_id == summary["topic_id"],
                    )
                )
            ).fetchall()
        by_id = {
            str(row._mapping["hop_id"]): dict(row._mapping) for row in rows
        }
        lineage: list[dict[str, Any]] = []
        current_id = str(summary.get("latest_hop_id") or "")
        seen: set[str] = set()
        while current_id and current_id not in seen and len(lineage) < 1000:
            seen.add(current_id)
            hop = by_id.get(current_id)
            if hop is None:
                break
            lineage.append(hop)
            current_id = str(hop.get("previous_hop_id") or "")
        lineage.reverse()
        messages: list[dict[str, Any]] = []
        for hop in lineage:
            raw_query = str(hop.get("raw_user_query") or "").strip()
            if raw_query:
                messages.append({"role": "user", "content": raw_query})
            try:
                entities = json.loads(str(hop.get("entities_json") or "{}"))
            except (TypeError, ValueError, json.JSONDecodeError):
                entities = {}
            response = str(
                (entities.get("final_chat_text") if isinstance(entities, dict) else "")
                or hop.get("raw_response")
                or ""
            ).strip()
            artifacts = self.list_generated_artifacts_for_hop(
                user_id=user_id,
                hop_id=str(hop["hop_id"]),
                include_deleted=False,
            )
            messages.append(
                {
                    "role": "assistant",
                    "content": response,
                    "artifacts": artifacts,
                    "pending_confirmations": [],
                    "response_type": str(hop.get("response_type") or "normal"),
                    "conversation_topic_id": str(hop["topic_id"]),
                    "conversation_hop_id": str(hop["hop_id"]),
                }
            )
        return {**summary, "messages": messages}

    def _resolve_root_hop(
        self,
        cursor: Connection,
        *,
        reference_hop_id: str | None,
        user_id: str,
        topic_id: str,
    ) -> str | None:
        if not reference_hop_id:
            return None
        row = cursor.execute(
            select(
                func.coalesce(conversation_hops.c.root_hop_id, conversation_hops.c.hop_id)
            )
            .select_from(
                conversation_hops.join(
                    conversation_topics,
                    and_(
                        conversation_topics.c.topic_id == conversation_hops.c.topic_id,
                        conversation_topics.c.user_id == conversation_hops.c.user_id,
                    ),
                )
            )
            .where(
                and_(
                    conversation_hops.c.hop_id == reference_hop_id,
                    conversation_hops.c.user_id == user_id,
                    conversation_hops.c.topic_id == topic_id,
                    conversation_topics.c.status == "active",
                )
            )
        ).fetchone()
        if not row:
            raise ValueError("Active conversation hop not found for user and topic")
        root_hop_id = str(row[0])
        self._require_owned_conversation_hop(
            cursor,
            user_id=user_id,
            hop_id=root_hop_id,
            topic_id=topic_id,
            require_active_topic=True,
        )
        return root_hop_id

    def _resolve_depth(
        self,
        cursor: Connection,
        *,
        reference_hop_id: str | None,
        user_id: str,
        topic_id: str,
    ) -> int:
        if not reference_hop_id:
            return 0
        row = cursor.execute(
            select(conversation_hops.c.depth_from_root)
            .select_from(
                conversation_hops.join(
                    conversation_topics,
                    and_(
                        conversation_topics.c.topic_id == conversation_hops.c.topic_id,
                        conversation_topics.c.user_id == conversation_hops.c.user_id,
                    ),
                )
            )
            .where(
                and_(
                    conversation_hops.c.hop_id == reference_hop_id,
                    conversation_hops.c.user_id == user_id,
                    conversation_hops.c.topic_id == topic_id,
                    conversation_topics.c.status == "active",
                )
            )
        ).fetchone()
        if not row:
            raise ValueError("Active conversation hop not found for user and topic")
        return int(row[0]) + 1

    def _require_owned_conversation_hop(
        self,
        cursor: Connection,
        *,
        user_id: str,
        hop_id: str,
        topic_id: str | None = None,
        require_active_topic: bool = False,
        for_update: bool = False,
    ) -> dict[str, Any]:
        conditions = [
            conversation_hops.c.user_id == user_id,
            conversation_hops.c.hop_id == hop_id,
        ]
        if topic_id is not None:
            conditions.append(conversation_hops.c.topic_id == topic_id)
        if require_active_topic:
            conditions.append(conversation_topics.c.status == "active")
        statement = (
            select(
                conversation_hops,
                conversation_topics.c.status.label("topic_status"),
                conversation_topics.c.entities_json.label("topic_entities_json"),
            )
            .select_from(
                conversation_hops.join(
                    conversation_topics,
                    and_(
                        conversation_topics.c.topic_id == conversation_hops.c.topic_id,
                        conversation_topics.c.user_id == conversation_hops.c.user_id,
                    ),
                )
            )
            .where(and_(*conditions))
            .limit(1)
        )
        if for_update:
            statement = statement.with_for_update()
        row = cursor.execute(statement).fetchone()
        if not row:
            qualifier = "Active conversation hop" if require_active_topic else "Conversation hop"
            raise ValueError(f"{qualifier} not found for user and topic")
        return dict(row._mapping)

    def scan_due_reminders(self, *, now_value: str, limit: int = 100) -> list[str]:
        notified: list[str] = []
        with self.transaction() as cursor:
            due_expr = func.coalesce(reminders.c.next_fire_time, reminders.c.reminder_time)
            rows = cursor.execute(
                select(
                    reminders.c.reminder_id,
                    reminders.c.user_id,
                    reminders.c.reminder_time,
                    reminders.c.recurrence_rule,
                    reminders.c.recurrence_timezone,
                    reminders.c.next_fire_time,
                    reminders.c.version,
                )
                # Deliberately global across users. The notification row still
                # carries the owning user_id and remains access-controlled.
                .where(and_(
                    reminders.c.status == "scheduled",
                    reminders.c.timing_plan_status == "planned",
                    due_expr <= now_value,
                ))
                .order_by(due_expr)
                .limit(limit)
                .with_for_update(skip_locked=True)
            ).fetchall()
            for row in rows:
                fire_time = row.next_fire_time or row.reminder_time
                self.create_notification_if_absent(
                    cursor,
                    user_id=row.user_id,
                    reminder_id=row.reminder_id,
                    fire_time=fire_time,
                )
                if row.recurrence_rule:
                    completed_occurrences = int(
                        cursor.execute(
                            select(func.count()).select_from(
                                reminder_notifications
                            ).where(
                                and_(
                                    reminder_notifications.c.reminder_id
                                    == row.reminder_id,
                                    reminder_notifications.c.user_id
                                    == row.user_id,
                                )
                            )
                        ).scalar_one()
                    )
                    next_fire_time = calculate_next_fire_time(
                        previous_fire_time=fire_time,
                        recurrence_rule=row.recurrence_rule,
                        recurrence_timezone=row.recurrence_timezone or "UTC",
                        completed_occurrences=completed_occurrences,
                    )
                    values = {
                        "status": "scheduled",
                        "last_fire_time": fire_time,
                        "next_fire_time": next_fire_time,
                        "updated_at": now_iso(),
                        "version": reminders.c.version + 1,
                    }
                    if next_fire_time is None:
                        values["status"] = "completed"
                    transition = cursor.execute(
                        update(reminders)
                        .where(
                            and_(
                                reminders.c.reminder_id == row.reminder_id,
                                reminders.c.user_id == row.user_id,
                                reminders.c.status == "scheduled",
                                reminders.c.version == row.version,
                            )
                        )
                        .values(**values)
                    )
                else:
                    transition = cursor.execute(
                        update(reminders)
                        .where(
                            and_(
                                reminders.c.reminder_id == row.reminder_id,
                                reminders.c.user_id == row.user_id,
                                reminders.c.status == "scheduled",
                                reminders.c.version == row.version,
                            )
                        )
                        .values(
                            status="notified",
                            last_fire_time=fire_time,
                            next_fire_time=None,
                            updated_at=now_iso(),
                            version=reminders.c.version + 1,
                        )
                    )
                if transition.rowcount != 1:
                    raise ReminderConflictError(
                        "Autoscan reminder transition lost its scheduled version."
                    )
                notified.append(str(row.reminder_id))
        GLOBAL_METRICS.increment("reminder_scans_total")
        GLOBAL_METRICS.increment("notification_created_total", len(notified))
        return notified

    def list_reminders_requiring_timing(self, *, limit: int = 100) -> list[PendingReminderTiming]:
        stmt = (
            select(
                reminders.c.reminder_id, reminders.c.user_id, reminders.c.event_time,
                reminders.c.reminder_time, reminders.c.subject, reminders.c.raw_reminder,
                reminders.c.user_timezone, reminders.c.recurrence_rule, reminders.c.version,
            )
            .where(and_(
                reminders.c.status == "scheduled",
                reminders.c.timing_plan_status == "pending",
            ))
            .order_by(func.coalesce(reminders.c.event_time, reminders.c.reminder_time), reminders.c.reminder_id)
            .limit(limit)
        )
        with self.engine.connect() as conn:
            rows = conn.execute(stmt).fetchall()
        candidates: list[PendingReminderTiming] = []
        for row in rows:
            source_value = row.event_time or row.reminder_time
            try:
                source_time = datetime.fromisoformat(source_value)
                if source_time.tzinfo is None:
                    source_time = source_time.replace(tzinfo=timezone.utc)
            except (TypeError, ValueError):
                source_time = datetime.min.replace(tzinfo=timezone.utc)
            candidates.append(PendingReminderTiming(
                reminder_id=str(row.reminder_id), user_id=str(row.user_id),
                source_time=source_time, subject=str(row.subject or ""),
                raw_reminder=str(row.raw_reminder or ""),
                user_timezone=str(row.user_timezone or "UTC"),
                recurrence_rule=row.recurrence_rule, version=int(row.version),
            ))
        return candidates

    def complete_reminder_timing_plan(
        self, *, reminder_id: str, user_id: str, expected_version: int,
        notification_time: datetime, reason: str,
    ) -> bool:
        notification_iso = notification_time.astimezone(timezone.utc).isoformat()
        with self.transaction() as cursor:
            result = cursor.execute(
                update(reminders)
                .where(and_(
                    reminders.c.reminder_id == reminder_id,
                    reminders.c.user_id == user_id,
                    reminders.c.version == expected_version,
                    reminders.c.status == "scheduled",
                    reminders.c.timing_plan_status == "pending",
                ))
                .values(
                    reminder_time=notification_iso,
                    next_fire_time=case(
                        (reminders.c.recurrence_rule.is_not(None), notification_iso),
                        else_=None,
                    ),
                    timing_plan_status="planned", timing_planned_at=now_iso(),
                    timing_plan_reason=reason, updated_at=now_iso(),
                    version=reminders.c.version + 1,
                )
            )
            return result.rowcount == 1

    def fail_reminder_timing_plan(
        self, *, reminder_id: str, user_id: str, expected_version: int, reason: str,
    ) -> bool:
        with self.transaction() as cursor:
            result = cursor.execute(
                update(reminders)
                .where(and_(
                    reminders.c.reminder_id == reminder_id,
                    reminders.c.user_id == user_id,
                    reminders.c.version == expected_version,
                    reminders.c.status == "scheduled",
                    reminders.c.timing_plan_status == "pending",
                ))
                .values(
                    timing_plan_status="needs_review", timing_planned_at=now_iso(),
                    timing_plan_reason=reason, updated_at=now_iso(),
                    version=reminders.c.version + 1,
                )
            )
            return result.rowcount == 1

    def list_reminders_requiring_supporting_question(
        self, *, limit: int = 100
    ) -> list[PendingReminderSupportingQuestion]:
        stmt = (
            select(
                reminders.c.reminder_id,
                reminders.c.user_id,
                reminders.c.subject,
                reminders.c.reminder_summary,
                reminders.c.raw_reminder,
                reminders.c.reminder_time,
                reminders.c.event_time,
                reminders.c.user_timezone,
                reminders.c.recurrence_rule,
                reminders.c.version,
            )
            .where(
                and_(
                    reminders.c.status == "scheduled",
                    reminders.c.supporting_question_plan_status == "pending",
                )
            )
            .order_by(
                func.coalesce(reminders.c.event_time, reminders.c.reminder_time),
                reminders.c.reminder_id,
            )
            .limit(limit)
        )
        with self.engine.connect() as conn:
            rows = conn.execute(stmt).fetchall()
        return [
            PendingReminderSupportingQuestion(
                reminder_id=str(row.reminder_id),
                user_id=str(row.user_id),
                subject=str(row.subject or ""),
                reminder_summary=str(row.reminder_summary or ""),
                raw_reminder=str(row.raw_reminder or ""),
                notification_time=_optional_datetime(row.reminder_time),
                event_time=_optional_datetime(row.event_time),
                user_timezone=str(row.user_timezone or "UTC"),
                recurrence_rule=(
                    str(row.recurrence_rule)
                    if row.recurrence_rule is not None
                    else None
                ),
                version=int(row.version),
            )
            for row in rows
        ]

    def complete_reminder_supporting_question_plan(
        self,
        *,
        reminder_id: str,
        user_id: str,
        expected_version: int,
        question: str | None,
        confidence: float,
        reason: str,
    ) -> bool:
        timestamp = now_iso()
        with self.transaction() as cursor:
            result = cursor.execute(
                update(reminders)
                .where(
                    and_(
                        reminders.c.reminder_id == reminder_id,
                        reminders.c.user_id == user_id,
                        reminders.c.version == expected_version,
                        reminders.c.status == "scheduled",
                        reminders.c.supporting_question_plan_status == "pending",
                    )
                )
                .values(
                    supporting_question=question,
                    supporting_question_plan_status="planned",
                    supporting_question_planned_at=timestamp,
                    supporting_question_plan_reason=reason,
                    supporting_question_confidence=confidence,
                    updated_at=timestamp,
                    version=reminders.c.version + 1,
                )
            )
            return result.rowcount == 1

    def fail_reminder_supporting_question_plan(
        self,
        *,
        reminder_id: str,
        user_id: str,
        expected_version: int,
        reason: str,
    ) -> bool:
        timestamp = now_iso()
        with self.transaction() as cursor:
            result = cursor.execute(
                update(reminders)
                .where(
                    and_(
                        reminders.c.reminder_id == reminder_id,
                        reminders.c.user_id == user_id,
                        reminders.c.version == expected_version,
                        reminders.c.status == "scheduled",
                        reminders.c.supporting_question_plan_status == "pending",
                    )
                )
                .values(
                    supporting_question_plan_status="needs_review",
                    supporting_question_planned_at=timestamp,
                    supporting_question_plan_reason=reason,
                    supporting_question_confidence=None,
                    updated_at=timestamp,
                    version=reminders.c.version + 1,
                )
            )
            return result.rowcount == 1

    def load_reminder_reply_context(self, *, user_id: str, reminder_id: str, notification_id: str) -> dict[str, Any]:
        stmt = select(
            reminders.c.reminder_id,
            reminder_notifications.c.notification_id,
            reminders.c.subject,
            reminders.c.reminder_summary,
            reminders.c.raw_reminder,
            reminders.c.status.label("reminder_status"),
            reminders.c.reminder_time,
            reminders.c.event_time,
            reminders.c.user_timezone,
            reminders.c.original_time_text,
            reminders.c.recurrence_rule,
            reminders.c.recurrence_timezone,
            reminders.c.next_fire_time,
            reminders.c.last_fire_time,
            reminders.c.parent_recurring_reminder_id,
            reminders.c.timing_plan_status,
            reminders.c.supporting_question_plan_status,
            reminders.c.supporting_question_confidence,
            reminders.c.supporting_question,
            reminders.c.supporting_response,
            reminder_notifications.c.source_topic_id,
            reminder_notifications.c.source_hop_id,
            reminder_notifications.c.ui_status.label("notification_ui_status"),
            reminder_notifications.c.delivery_status.label("notification_delivery_status"),
            reminder_notifications.c.fire_time.label("notification_fire_time"),
            reminder_notifications.c.created_at.label("notification_created_at"),
            conversation_hops.c.topic_id,
            conversation_hops.c.rewritten_user_query.label("source_rewritten_user_query"),
            conversation_hops.c.raw_response.label("source_raw_response"),
            conversation_hops.c.supporting_questions_json,
            conversation_hops.c.response_type.label("source_response_type"),
            conversation_hops.c.entities_json.label("source_entities_json"),
        ).select_from(
            reminders.join(
                reminder_notifications,
                reminders.c.reminder_id == reminder_notifications.c.reminder_id
            ).outerjoin(
                conversation_hops,
                and_(
                    reminder_notifications.c.source_hop_id == conversation_hops.c.hop_id,
                    reminders.c.user_id == conversation_hops.c.user_id,
                ),
            )
        ).where(
            and_(
                reminders.c.user_id == user_id,
                reminders.c.reminder_id == reminder_id,
                reminder_notifications.c.notification_id == notification_id
            )
        )
        with self.engine.connect() as conn:
            row = conn.execute(stmt).fetchone()
            if not row:
                raise ValueError("Reminder not found or does not belong to user")
            
            return dict(row._mapping)


    def add_knowledge_chunk(
        self,
        cursor: Connection,
        *,
        user_id: str,
        title: str,
        text: str,
        source_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        replaces_chunk_id: str | None = None,
        change_reason: str | None = None,
        modified_by_user_query: str | None = None,
        knowledge_topic_id: str | None = None,
    ) -> tuple[str, str, str | None]:
        user_id = require_stable_user_id(user_id)
        normalized = " ".join(str(text or "").split())
        if not normalized:
            raise RepositoryValidationError(
                "Knowledge chunk text must contain non-whitespace content"
            )
        if source_id is not None:
            source_row = cursor.execute(
                select(knowledge_sources.c.source_id).where(
                    and_(
                        knowledge_sources.c.source_id == source_id,
                        knowledge_sources.c.user_id == user_id,
                        knowledge_sources.c.is_deleted == 0,
                        knowledge_sources.c.processing_status != "deleted",
                    )
                )
            ).fetchone()
            if not source_row:
                raise KnowledgeConflictError(
                    "Knowledge source not found for user"
                )
        if knowledge_topic_id is not None:
            topic_row = cursor.execute(
                select(knowledge_topics.c.knowledge_topic_id).where(
                    and_(
                        knowledge_topics.c.user_id == user_id,
                        knowledge_topics.c.knowledge_topic_id
                        == knowledge_topic_id,
                    )
                )
            ).fetchone()
            if not topic_row:
                raise KnowledgeConflictError(
                    "Knowledge topic not found for user"
                )
            topic_id = str(topic_row[0])
        else:
            topic_id = self.ensure_knowledge_topic(
                cursor,
                user_id=user_id,
                title=title,
            )
        
        c_hash = knowledge_chunk_content_hash(
            user_id,
            normalized,
            source_id=source_id,
        )
        
        stmt = select(knowledge_chunks.c.chunk_id, knowledge_chunks.c.is_deleted).where(
            and_(
                knowledge_chunks.c.user_id == user_id,
                knowledge_chunks.c.knowledge_topic_id == topic_id,
                knowledge_chunks.c.content_hash == c_hash,
            )
        )
        existing = cursor.execute(stmt).fetchone()
        if existing is None and source_id is not None:
            legacy_hash = content_hash(user_id, normalized)
            legacy_stmt = (
                select(
                    knowledge_chunks.c.chunk_id,
                    knowledge_chunks.c.is_deleted,
                )
                .where(
                    and_(
                        knowledge_chunks.c.user_id == user_id,
                        knowledge_chunks.c.knowledge_topic_id == topic_id,
                        knowledge_chunks.c.source_id == source_id,
                        knowledge_chunks.c.content_hash == legacy_hash,
                    )
                )
                .order_by(knowledge_chunks.c.created_at.desc())
                .limit(1)
            )
            existing = cursor.execute(legacy_stmt).fetchone()
            if existing is not None:
                cursor.execute(
                    update(knowledge_chunks)
                    .where(
                        and_(
                            knowledge_chunks.c.user_id == user_id,
                            knowledge_chunks.c.chunk_id == existing.chunk_id,
                        )
                    )
                    .values(content_hash=c_hash)
                )
        
        if existing:
            existing_chunk_id = existing.chunk_id
            if existing.is_deleted == 0:
                return topic_id, existing_chunk_id, None
            else:
                update_stmt = update(knowledge_chunks).where(
                    knowledge_chunks.c.chunk_id == existing_chunk_id
                ).values(
                    is_deleted=0,
                updated_at=now_iso(),
                version=knowledge_chunks.c.version + 1
            )
                cursor.execute(update_stmt)
                outbox_job_id = self.insert_outbox_job(
                    cursor,
                    entity_type=OutboxEntityType.KNOWLEDGE_CHUNK,
                    entity_id=existing_chunk_id,
                    operation=OutboxOperation.UPSERT,
                )
                return topic_id, existing_chunk_id, outbox_job_id
                
        chunk_id = new_id()
        timestamp = now_iso()
        next_chunk_index = cursor.execute(
            select(
                (func.coalesce(func.max(knowledge_chunks.c.chunk_index), -1) + 1)
                .label("next_index")
            ).where(
                and_(
                    knowledge_chunks.c.user_id == user_id,
                    knowledge_chunks.c.knowledge_topic_id == topic_id,
                )
            )
        ).scalar_one()
        
        values = {
            "chunk_id": chunk_id,
            "knowledge_topic_id": topic_id,
            "user_id": user_id,
            "source_id": source_id,
            "chunk_index": int(next_chunk_index),
            "raw_text": text,
            "normalized_text": normalized,
            "summary": normalized,
            "metadata_json": json.dumps(metadata or {}),
            "content_hash": c_hash,
            "is_deleted": 0,
            "created_at": timestamp,
            "updated_at": timestamp,
            "version": 1,
            "replaces_chunk_id": replaces_chunk_id,
            "change_reason": change_reason,
            "modified_by_user_query": modified_by_user_query,
        }
        dialect_name = cursor.dialect.name
        if dialect_name == "postgresql":
            create_statement = postgresql_insert(knowledge_chunks).values(**values)
        elif dialect_name == "sqlite":
            create_statement = sqlite_insert(knowledge_chunks).values(**values)
        else:
            raise RepositoryValidationError(
                f"Unsupported SQL dialect for conflict-safe knowledge chunks: {dialect_name}"
            )
        inserted = cursor.execute(
            create_statement.on_conflict_do_nothing(
                index_elements=[
                    knowledge_chunks.c.user_id,
                    knowledge_chunks.c.knowledge_topic_id,
                    knowledge_chunks.c.content_hash,
                ]
            )
        )
        if inserted.rowcount != 1:
            concurrent = cursor.execute(stmt).fetchone()
            if not concurrent:
                raise KnowledgeConflictError(
                    "Knowledge chunk could not be resolved after a concurrent write"
                )
            concurrent_chunk_id = str(concurrent.chunk_id)
            if concurrent.is_deleted == 0:
                return topic_id, concurrent_chunk_id, None
            cursor.execute(
                update(knowledge_chunks)
                .where(
                    and_(
                        knowledge_chunks.c.user_id == user_id,
                        knowledge_chunks.c.chunk_id == concurrent_chunk_id,
                    )
                )
                .values(
                    is_deleted=0,
                    updated_at=now_iso(),
                    version=knowledge_chunks.c.version + 1,
                )
            )
            outbox_job_id = self.insert_outbox_job(
                cursor,
                entity_type=OutboxEntityType.KNOWLEDGE_CHUNK,
                entity_id=concurrent_chunk_id,
                operation=OutboxOperation.UPSERT,
            )
            return topic_id, concurrent_chunk_id, outbox_job_id

        outbox_job_id = self.insert_outbox_job(
            cursor,
            entity_type=OutboxEntityType.KNOWLEDGE_CHUNK,
            entity_id=chunk_id,
            operation=OutboxOperation.UPSERT,
        )
        return topic_id, chunk_id, outbox_job_id

    def ensure_knowledge_topic(
        self,
        cursor: Connection,
        *,
        user_id: str,
        title: str,
    ) -> str:
        stmt = select(knowledge_topics.c.knowledge_topic_id).where(
            and_(
                knowledge_topics.c.user_id == user_id,
                knowledge_topics.c.title == title
            )
        ).order_by(knowledge_topics.c.updated_at.desc()).limit(1)
        row = cursor.execute(stmt).fetchone()
        if row:
            return str(row[0])
            
        topic_id = new_id()
        timestamp = now_iso()
        values = {
            "knowledge_topic_id": topic_id,
            "user_id": user_id,
            "title": title,
            "description": "",
            "entities_json": "{}",
            "created_at": timestamp,
            "updated_at": timestamp,
            "version": 1,
        }
        dialect_name = cursor.dialect.name
        if dialect_name == "postgresql":
            create_statement = postgresql_insert(knowledge_topics).values(**values)
        elif dialect_name == "sqlite":
            create_statement = sqlite_insert(knowledge_topics).values(**values)
        else:
            raise RepositoryValidationError(
                f"Unsupported SQL dialect for conflict-safe knowledge topics: {dialect_name}"
            )
        cursor.execute(
            create_statement.on_conflict_do_nothing(
                index_elements=[
                    knowledge_topics.c.user_id,
                    knowledge_topics.c.title,
                ]
            )
        )
        resolved = cursor.execute(
            select(knowledge_topics.c.knowledge_topic_id).where(
                and_(
                    knowledge_topics.c.user_id == user_id,
                    knowledge_topics.c.title == title,
                )
            )
        ).fetchone()
        if not resolved:
            raise KnowledgeConflictError("Knowledge topic could not be resolved")
        return str(resolved[0])

    @staticmethod
    def _touch_knowledge_topic(
        cursor: Connection,
        *,
        user_id: str,
        knowledge_topic_id: str,
    ) -> None:
        result = cursor.execute(
            update(knowledge_topics)
            .where(
                and_(
                    knowledge_topics.c.user_id == user_id,
                    knowledge_topics.c.knowledge_topic_id
                    == knowledge_topic_id,
                )
            )
            .values(
                updated_at=now_iso(),
                version=knowledge_topics.c.version + 1,
            )
        )
        if result.rowcount != 1:
            raise KnowledgeConflictError(
                "Knowledge topic changed before mutation completion"
            )

    def get_knowledge_chunks_by_ids(
        self, user_id: str, chunk_ids: list[str], include_deleted: bool = False
    ) -> list[dict[str, Any]]:
        if not chunk_ids:
            return []
            
        stmt = select(knowledge_chunks).where(
            and_(
                knowledge_chunks.c.user_id == user_id,
                knowledge_chunks.c.chunk_id.in_(chunk_ids)
            )
        )
        if not include_deleted:
            stmt = stmt.where(knowledge_chunks.c.is_deleted == 0)
            
        with self.engine.connect() as conn:
            rows = conn.execute(stmt).fetchall()
            return [dict(r._mapping) for r in rows]

    def soft_delete_knowledge_chunk(
        self,
        cursor: Connection,
        *,
        user_id: str,
        chunk_id: str,
        expected_version: int | None = None,
        change_reason: str | None = None,
        modified_by_user_query: str | None = None,
    ) -> str:
        timestamp = now_iso()
        stmt = update(knowledge_chunks).where(
            and_(
                knowledge_chunks.c.user_id == user_id,
                knowledge_chunks.c.chunk_id == chunk_id,
                knowledge_chunks.c.is_deleted == 0
            )
        )
        if expected_version is not None:
            stmt = stmt.where(knowledge_chunks.c.version == expected_version)
            
        stmt = stmt.values(
            is_deleted=1,
            updated_at=timestamp,
            version=knowledge_chunks.c.version + 1,
            change_reason=func.coalesce(change_reason, knowledge_chunks.c.change_reason),
            modified_by_user_query=func.coalesce(modified_by_user_query, knowledge_chunks.c.modified_by_user_query),
        )
        
        res = cursor.execute(stmt)
        if res.rowcount != 1:
            raise KnowledgeConflictError("Active knowledge chunk not found or version mismatch for user")
            
        outbox_job_id = self.insert_outbox_job(
            cursor,
            entity_type=OutboxEntityType.KNOWLEDGE_CHUNK,
            entity_id=chunk_id,
            operation=OutboxOperation.DELETE,
        )
        return outbox_job_id

    def create_knowledge_source(
        self,
        cursor: Connection,
        *,
        user_id: str,
        filename: str,
        file_type: str,
        content_hash: str,
        metadata: dict[str, Any] | None = None,
        processing_status: str = "pending",
    ) -> str:
        user_id = require_stable_user_id(user_id)
        source_id = new_id()
        timestamp = now_iso()
        cursor.execute(
            insert(knowledge_sources).values(
                source_id=source_id,
                user_id=user_id,
                filename=filename,
                file_type=file_type,
                upload_time=timestamp,
                processing_status=processing_status,
                content_hash=content_hash,
                metadata_json=json.dumps(metadata or {}),
                version=1,
                is_deleted=0,
                created_at=timestamp,
                updated_at=timestamp,
            )
        )
        return source_id

    def update_knowledge_source_status(
        self,
        cursor: Connection,
        *,
        user_id: str,
        source_id: str,
        processing_status: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        values = {
            "processing_status": processing_status,
            "updated_at": now_iso(),
            "version": knowledge_sources.c.version + 1,
        }
        if metadata is not None:
            values["metadata_json"] = json.dumps(metadata)
        result = cursor.execute(
            update(knowledge_sources)
            .where(and_(knowledge_sources.c.user_id == user_id, knowledge_sources.c.source_id == source_id))
            .values(**values)
        )
        if result.rowcount != 1:
            raise KnowledgeConflictError("Knowledge source not found for user")

    def list_knowledge_sources(self, *, user_id: str, include_deleted: bool = False) -> list[dict[str, Any]]:
        stmt = select(knowledge_sources).where(knowledge_sources.c.user_id == user_id)
        if not include_deleted:
            stmt = stmt.where(and_(knowledge_sources.c.is_deleted == 0, knowledge_sources.c.processing_status != "deleted"))
        stmt = stmt.order_by(knowledge_sources.c.created_at.desc())
        with self.engine.connect() as conn:
            return [dict(row._mapping) for row in conn.execute(stmt).fetchall()]

    def get_knowledge_source(self, *, user_id: str, source_id: str, include_deleted: bool = False) -> dict[str, Any]:
        stmt = select(knowledge_sources).where(
            and_(knowledge_sources.c.user_id == user_id, knowledge_sources.c.source_id == source_id)
        )
        if not include_deleted:
            stmt = stmt.where(and_(knowledge_sources.c.is_deleted == 0, knowledge_sources.c.processing_status != "deleted"))
        with self.engine.connect() as conn:
            row = conn.execute(stmt).fetchone()
        if not row:
            raise ValueError("Knowledge source not found for user")
        return dict(row._mapping)

    def soft_delete_knowledge_source(self, *, user_id: str, source_id: str) -> dict[str, Any]:
        outbox_job_ids: list[str] = []
        with self.transaction() as cursor:
            result = cursor.execute(
                update(knowledge_sources)
                .where(and_(knowledge_sources.c.user_id == user_id, knowledge_sources.c.source_id == source_id, knowledge_sources.c.is_deleted == 0))
                .values(is_deleted=1, processing_status="deleted", updated_at=now_iso(), version=knowledge_sources.c.version + 1)
            )
            if result.rowcount != 1:
                raise ValueError("Knowledge source not found for user")
            rows = cursor.execute(
                select(knowledge_chunks.c.chunk_id).where(
                    and_(
                        knowledge_chunks.c.user_id == user_id,
                        knowledge_chunks.c.source_id == source_id,
                        knowledge_chunks.c.is_deleted == 0,
                    )
                )
            ).fetchall()
            for row in rows:
                outbox_job_ids.append(
                    self.soft_delete_knowledge_chunk(
                        cursor,
                        user_id=user_id,
                        chunk_id=row[0],
                        change_reason="source_deleted",
                    )
                )
        payload = self.get_knowledge_source(user_id=user_id, source_id=source_id, include_deleted=True)
        payload["outbox_job_ids"] = outbox_job_ids
        return payload

    def reindex_knowledge_source(self, *, user_id: str, source_id: str) -> list[str]:
        outbox_job_ids: list[str] = []
        with self.transaction() as cursor:
            source = cursor.execute(
                select(knowledge_sources.c.source_id).where(
                    and_(
                        knowledge_sources.c.user_id == user_id,
                        knowledge_sources.c.source_id == source_id,
                        knowledge_sources.c.is_deleted == 0,
                        knowledge_sources.c.processing_status != "deleted",
                    )
                )
            ).fetchone()
            if not source:
                raise ValueError("Knowledge source not found for user")
            rows = cursor.execute(
                select(knowledge_chunks.c.chunk_id).where(
                    and_(knowledge_chunks.c.user_id == user_id, knowledge_chunks.c.source_id == source_id, knowledge_chunks.c.is_deleted == 0)
                )
            ).fetchall()
            for row in rows:
                outbox_job_ids.append(
                    self.insert_outbox_job(
                        cursor,
                        entity_type=OutboxEntityType.KNOWLEDGE_CHUNK,
                        entity_id=row[0],
                        operation=OutboxOperation.UPSERT,
                    )
                )
        return outbox_job_ids

    def list_knowledge_facts(
        self, *, user_id: str, include_deleted: bool = False, source_id: str | None = None
    ) -> list[dict[str, Any]]:
        user_id = require_stable_user_id(user_id)
        stmt = select(knowledge_chunks).where(knowledge_chunks.c.user_id == user_id)
        if not include_deleted:
            stmt = stmt.where(knowledge_chunks.c.is_deleted == 0)
        if source_id is not None:
            stmt = stmt.where(knowledge_chunks.c.source_id == source_id)
        stmt = stmt.order_by(knowledge_chunks.c.created_at.desc())
        with self.engine.connect() as conn:
            return [dict(row._mapping) for row in conn.execute(stmt).fetchall()]

    def list_knowledge_recovery_candidates(
        self,
        *,
        user_id: str,
        limit: int,
        before_created_at: str | None = None,
        before_chunk_id: str | None = None,
    ) -> list[dict[str, Any]]:
        user_id = require_stable_user_id(user_id)
        page_size = int(limit)
        if page_size <= 0:
            raise ValueError("Knowledge recovery page size must be positive")
        if (before_created_at is None) != (before_chunk_id is None):
            raise ValueError("Knowledge recovery cursor must be complete")
        stmt = select(knowledge_chunks).where(
            and_(
                knowledge_chunks.c.user_id == user_id,
                knowledge_chunks.c.is_deleted == 0,
            )
        )
        if before_created_at is not None and before_chunk_id is not None:
            stmt = stmt.where(
                or_(
                    knowledge_chunks.c.created_at < before_created_at,
                    and_(
                        knowledge_chunks.c.created_at == before_created_at,
                        knowledge_chunks.c.chunk_id < before_chunk_id,
                    ),
                )
            )
        stmt = stmt.order_by(
            knowledge_chunks.c.created_at.desc(),
            knowledge_chunks.c.chunk_id.desc(),
        ).limit(page_size)
        with self.engine.connect() as conn:
            return [dict(row._mapping) for row in conn.execute(stmt).fetchall()]

    def restore_knowledge_chunk(self, *, user_id: str, chunk_id: str) -> str:
        with self.transaction() as cursor:
            row = cursor.execute(
                select(
                    knowledge_chunks.c.chunk_id,
                    knowledge_chunks.c.source_id,
                    knowledge_sources.c.is_deleted,
                )
                .select_from(knowledge_chunks.outerjoin(knowledge_sources, and_(knowledge_sources.c.source_id == knowledge_chunks.c.source_id, knowledge_sources.c.user_id == knowledge_chunks.c.user_id)))
                .where(and_(knowledge_chunks.c.user_id == user_id, knowledge_chunks.c.chunk_id == chunk_id, knowledge_chunks.c.is_deleted == 1))
            ).fetchone()
            if not row:
                raise ValueError("Deleted knowledge chunk not found for user")
            if row[1] and row[2] == 1:
                raise ValueError("Cannot restore a chunk from a deleted source")
            cursor.execute(
                update(knowledge_chunks)
                .where(and_(knowledge_chunks.c.user_id == user_id, knowledge_chunks.c.chunk_id == chunk_id))
                .values(is_deleted=0, updated_at=now_iso(), version=knowledge_chunks.c.version + 1)
            )
            return self.insert_outbox_job(
                cursor,
                entity_type=OutboxEntityType.KNOWLEDGE_CHUNK,
                entity_id=chunk_id,
                operation=OutboxOperation.UPSERT,
            )

    def update_knowledge_chunk_text(
        self,
        *,
        user_id: str,
        chunk_id: str,
        text: str,
        change_reason: str | None = None,
        modified_by_user_query: str | None = None,
    ) -> dict[str, Any]:
        existing = self.get_knowledge_chunks_by_ids(user_id, [chunk_id], include_deleted=False)
        if not existing:
            raise ValueError("Active knowledge chunk not found for user")
        old = existing[0]
        with self.transaction() as cursor:
            delete_job_id = self.soft_delete_knowledge_chunk(
                cursor,
                user_id=user_id,
                chunk_id=chunk_id,
                expected_version=old.get("version"),
                change_reason=change_reason or "manual_update",
                modified_by_user_query=modified_by_user_query,
            )
            topic_row = cursor.execute(
                select(knowledge_topics.c.title).where(
                    and_(knowledge_topics.c.user_id == user_id, knowledge_topics.c.knowledge_topic_id == old["knowledge_topic_id"])
                )
            ).fetchone()
            _, new_chunk_id, upsert_job_id = self.add_knowledge_chunk(
                cursor,
                user_id=user_id,
                title=topic_row[0] if topic_row else "Knowledge",
                text=text,
                source_id=old.get("source_id"),
                metadata=json.loads(old.get("metadata_json") or "{}"),
                replaces_chunk_id=chunk_id,
                change_reason=change_reason,
                modified_by_user_query=modified_by_user_query,
            )
            cursor.execute(
                update(knowledge_chunks)
                .where(and_(knowledge_chunks.c.user_id == user_id, knowledge_chunks.c.chunk_id == chunk_id))
                .values(replaced_by_chunk_id=new_chunk_id)
            )
        return {
            "old_chunk_id": chunk_id,
            "new_chunk_id": new_chunk_id,
            "outbox_job_ids": [job for job in (delete_job_id, upsert_job_id) if job],
        }

    def create_generated_artifact(
        self,
        *,
        user_id: str,
        conversation_hop_id: str | None,
        file_type: str,
        filename: str,
        storage_path: str,
        storage_url: str,
        metadata: dict[str, Any] | None = None,
        expires_at: str | None = None,
    ) -> dict[str, Any]:
        artifact_id = new_id()
        timestamp = now_iso()
        with self.transaction() as cursor:
            if conversation_hop_id is not None:
                self._require_owned_conversation_hop(
                    cursor,
                    user_id=user_id,
                    hop_id=conversation_hop_id,
                )
            cursor.execute(
                insert(generated_artifacts).values(
                    artifact_id=artifact_id,
                    user_id=user_id,
                    conversation_hop_id=conversation_hop_id,
                    file_type=file_type,
                    filename=filename,
                    storage_path=storage_path,
                    storage_url=storage_url,
                    metadata_json=json.dumps(metadata or {}),
                    created_at=timestamp,
                    expires_at=expires_at,
                    status=ArtifactStatus.CREATED.value,
                )
            )
        return self.get_generated_artifact(user_id=user_id, artifact_id=artifact_id)

    def list_generated_artifacts(self, *, user_id: str, include_deleted: bool = False) -> list[dict[str, Any]]:
        stmt = select(generated_artifacts).where(generated_artifacts.c.user_id == user_id)
        if not include_deleted:
            stmt = stmt.where(generated_artifacts.c.status == ArtifactStatus.CREATED.value)
        stmt = stmt.order_by(generated_artifacts.c.created_at.desc())
        with self.engine.connect() as conn:
            return [dict(row._mapping) for row in conn.execute(stmt).fetchall()]

    def get_generated_artifact(self, *, user_id: str, artifact_id: str, include_deleted: bool = False) -> dict[str, Any]:
        stmt = select(generated_artifacts).where(
            and_(generated_artifacts.c.user_id == user_id, generated_artifacts.c.artifact_id == artifact_id)
        )
        if not include_deleted:
            stmt = stmt.where(generated_artifacts.c.status == ArtifactStatus.CREATED.value)
        with self.engine.connect() as conn:
            row = conn.execute(stmt).fetchone()
        if not row:
            raise ValueError("Artifact not found for user")
        payload = dict(row._mapping)
        if not include_deleted and not is_artifact_downloadable(payload):
            raise ValueError("Artifact not found for user")
        return payload

    def list_generated_artifacts_for_hop(
        self,
        *,
        user_id: str,
        hop_id: str,
        include_deleted: bool = False,
    ) -> list[dict[str, Any]]:
        with self.engine.connect() as conn:
            self._require_owned_conversation_hop(
                conn,
                user_id=user_id,
                hop_id=hop_id,
            )
            stmt = select(generated_artifacts).where(
                and_(
                    generated_artifacts.c.user_id == user_id,
                    generated_artifacts.c.conversation_hop_id == hop_id,
                )
            )
            if not include_deleted:
                stmt = stmt.where(
                    generated_artifacts.c.status == ArtifactStatus.CREATED.value
                )
            stmt = stmt.order_by(
                generated_artifacts.c.created_at.desc(),
                generated_artifacts.c.artifact_id.desc(),
            )
            payloads = [dict(row._mapping) for row in conn.execute(stmt).fetchall()]
            if not include_deleted:
                payloads = [row for row in payloads if is_artifact_downloadable(row)]
            return payloads

    def bind_generated_artifacts(
        self,
        *,
        user_id: str,
        artifact_ids: list[str],
        conversation_hop_id: str,
    ) -> list[str]:
        unique_ids = list(dict.fromkeys(str(value) for value in artifact_ids if value))
        if not unique_ids:
            return []
        if not conversation_hop_id:
            raise ValueError("Conversation hop not found for user and topic")
        with self.transaction() as cursor:
            self._require_owned_conversation_hop(
                cursor,
                user_id=user_id,
                hop_id=conversation_hop_id,
            )
            cursor.execute(
                update(generated_artifacts)
                .where(
                    and_(
                        generated_artifacts.c.user_id == user_id,
                        generated_artifacts.c.artifact_id.in_(unique_ids),
                        generated_artifacts.c.status == ArtifactStatus.CREATED.value,
                        or_(
                            generated_artifacts.c.conversation_hop_id.is_(None),
                            generated_artifacts.c.conversation_hop_id
                            == conversation_hop_id,
                        ),
                    )
                )
                .values(conversation_hop_id=conversation_hop_id)
            )
            rows = cursor.execute(
                select(generated_artifacts.c.artifact_id).where(
                    and_(
                        generated_artifacts.c.user_id == user_id,
                        generated_artifacts.c.artifact_id.in_(unique_ids),
                        generated_artifacts.c.conversation_hop_id
                        == conversation_hop_id,
                        generated_artifacts.c.status == ArtifactStatus.CREATED.value,
                    )
                )
            ).fetchall()
        bound = {str(row[0]) for row in rows}
        return [artifact_id for artifact_id in unique_ids if artifact_id in bound]

    def delete_generated_artifact(self, *, user_id: str, artifact_id: str) -> dict[str, Any]:
        with self.transaction() as cursor:
            result = cursor.execute(
                update(generated_artifacts)
                .where(and_(generated_artifacts.c.user_id == user_id, generated_artifacts.c.artifact_id == artifact_id, generated_artifacts.c.status == ArtifactStatus.CREATED.value))
                .values(status=ArtifactStatus.DELETED.value)
            )
            if result.rowcount != 1:
                raise ValueError("Artifact not found for user")
        return self.get_generated_artifact(user_id=user_id, artifact_id=artifact_id, include_deleted=True)

    def record_platform_delivery(self, *, user_id: str, conversation_hop_id: str | None, channel: str, status: str, recipient: str, message: dict[str, Any], error_message: str | None = None) -> dict[str, Any]:
        delivery_id = new_id()
        with self.transaction() as cursor:
            if conversation_hop_id is not None:
                self._require_owned_conversation_hop(
                    cursor,
                    user_id=user_id,
                    hop_id=conversation_hop_id,
                )
            cursor.execute(insert(platform_deliveries).values(
                delivery_id=delivery_id, user_id=user_id, conversation_hop_id=conversation_hop_id,
                channel=channel, status=status, recipient=recipient, message_json=json.dumps(message),
                error_message=error_message, created_at=now_iso(),
            ))
        return {"delivery_id": delivery_id, "channel": channel, "status": status}

    def get_latest_platform_delivery_for_hop(
        self,
        *,
        user_id: str,
        hop_id: str,
    ) -> dict[str, Any] | None:
        with self.engine.connect() as conn:
            self._require_owned_conversation_hop(
                conn,
                user_id=user_id,
                hop_id=hop_id,
            )
            row = conn.execute(
                select(platform_deliveries)
                .where(
                    and_(
                        platform_deliveries.c.user_id == user_id,
                        platform_deliveries.c.conversation_hop_id == hop_id,
                    )
                )
                .order_by(
                    platform_deliveries.c.created_at.desc(),
                    platform_deliveries.c.delivery_id.desc(),
                )
                .limit(1)
            ).fetchone()
        if not row:
            return None
        payload = dict(row._mapping)
        try:
            parsed_message = json.loads(str(payload.get("message_json") or "{}"))
        except (TypeError, ValueError, json.JSONDecodeError):
            parsed_message = {}
        payload["message"] = parsed_message if isinstance(parsed_message, dict) else {}
        return payload

    def add_reminder(
        self,
        cursor: Connection,
        *,
        user_id: str,
        source_topic_id: str | None,
        source_hop_id: str | None,
        reminder_time: str,
        raw_reminder: str,
        reminder_summary: str,
        subject: str,
        event_time: str | None = None,
        supporting_question: str | None = None,
        supporting_response: str | None = None,
        user_timezone: str = "UTC",
        original_time_text: str | None = None,
        recurrence_rule: str | None = None,
        recurrence_timezone: str | None = None,
        next_fire_time: str | None = None,
        parent_recurring_reminder_id: str | None = None,
    ) -> str:
        if not source_hop_id:
            raise RepositoryValidationError("A reminder must be bound to its source conversation hop")
        source = cursor.execute(
            select(conversation_hops.c.topic_id).where(
                and_(
                    conversation_hops.c.hop_id == source_hop_id,
                    conversation_hops.c.user_id == user_id,
                )
            )
        ).fetchone()
        if not source:
            raise RepositoryValidationError("Reminder source hop does not belong to this user")
        canonical_topic_id = str(source[0])
        if source_topic_id and source_topic_id != canonical_topic_id:
            raise RepositoryValidationError("Reminder source topic does not match its source hop")
        source_topic_id = canonical_topic_id
        reminder_id = new_id()
        timestamp = now_iso()
        has_existing_support = bool(
            str(supporting_question or "").strip()
            or str(supporting_response or "").strip()
        )
        cursor.execute(
            insert(reminders).values(
                reminder_id=reminder_id,
                user_id=user_id,
                source_topic_id=source_topic_id,
                source_hop_id=source_hop_id,
                reminder_time=reminder_time,
                event_time=event_time,
                supporting_question_plan_status=(
                    "planned" if has_existing_support else "pending"
                ),
                supporting_question_planned_at=(
                    timestamp if has_existing_support else None
                ),
                supporting_question_plan_reason=(
                    "Existing reminder supporting context was preserved."
                    if has_existing_support
                    else None
                ),
                supporting_question_confidence=(
                    1.0 if has_existing_support else None
                ),
                raw_reminder=raw_reminder,
                reminder_summary=reminder_summary,
                subject=subject,
                supporting_question=supporting_question,
                supporting_response=supporting_response,
                user_timezone=user_timezone,
                original_time_text=original_time_text,
                recurrence_rule=recurrence_rule,
                recurrence_timezone=recurrence_timezone,
                next_fire_time=next_fire_time,
                last_fire_time=None,
                parent_recurring_reminder_id=parent_recurring_reminder_id,
                status='scheduled',
                created_at=timestamp,
                updated_at=timestamp,
                version=1
            )
        )
        return reminder_id

    def update_reminder_status(
        self,
        cursor: Connection,
        *,
        user_id: str,
        reminder_id: str,
        status: str,
        expected_version: int | None = None,
        expected_status: str | None = None,
    ) -> None:
        stmt = update(reminders).where(
            and_(
                reminders.c.user_id == user_id,
                reminders.c.reminder_id == reminder_id
            )
        )
        if expected_version is not None:
            stmt = stmt.where(reminders.c.version == expected_version)
        if expected_status is not None:
            stmt = stmt.where(reminders.c.status == expected_status)
            
        stmt = stmt.values(
            status=status,
            updated_at=now_iso(),
            version=reminders.c.version + 1
        )
        
        res = cursor.execute(stmt)
        if res.rowcount != 1:
            raise ReminderConflictError("Reminder update failed ownership, version, or status validation")

    def create_notification_if_absent(
        self, cursor: Connection, *, user_id: str, reminder_id: str, fire_time: str | None = None
    ) -> str:
        stmt = select(reminder_notifications.c.notification_id).where(
            and_(
                reminder_notifications.c.user_id == user_id,
                reminder_notifications.c.reminder_id == reminder_id,
                func.coalesce(reminder_notifications.c.fire_time, "") == (fire_time or ""),
            )
        )
        row = cursor.execute(stmt).fetchone()
        if row:
            return str(row[0])
        source = cursor.execute(
            select(reminders.c.source_topic_id, reminders.c.source_hop_id).where(
                and_(
                    reminders.c.user_id == user_id,
                    reminders.c.reminder_id == reminder_id,
                )
            )
        ).fetchone()
        if not source or not source[1]:
            raise RepositoryValidationError("Reminder has no immutable source conversation hop")
            
        notification_id = new_id()
        cursor.execute(
            insert(reminder_notifications).values(
                notification_id=notification_id,
                reminder_id=reminder_id,
                user_id=user_id,
                source_topic_id=source[0],
                source_hop_id=source[1],
                ui_status='unread',
                delivery_status=NotificationDeliveryStatus.PENDING.value,
                delivery_attempts=0,
                created_at=now_iso(),
                fire_time=fire_time,
            )
        )
        return notification_id

    def insert_outbox_job(
        self,
        cursor: Connection,
        *,
        entity_type: OutboxEntityType,
        entity_id: str,
        operation: OutboxOperation,
    ) -> str:
        if entity_type.value in ('reminder', 'reminder_notification'):
            raise RepositoryValidationError(f"{entity_type.value} rows must not be indexed.")
            
        stmt = select(indexing_outbox.c.job_id).where(
            and_(
                indexing_outbox.c.entity_type == entity_type.value,
                indexing_outbox.c.entity_id == entity_id,
                indexing_outbox.c.operation == operation.value,
                indexing_outbox.c.status.in_(['pending', 'processing'])
            )
        ).limit(1)
        row = cursor.execute(stmt).fetchone()
        if row:
            return str(row[0])
            
        job_id = new_id()
        timestamp = now_iso()
        cursor.execute(
            insert(indexing_outbox).values(
                job_id=job_id,
                entity_type=entity_type.value,
                entity_id=entity_id,
                operation=operation.value,
                status='pending',
                retry_count=0,
                created_at=timestamp,
                updated_at=timestamp
            )
        )
        return job_id

    def record_action_audit_noop(
        self, *, user_id: str, topic_title: str, raw_user_query: str, rewritten_user_query: str, response_text: str, intent: str, response_type: str, parent_hop_id: str | None = None, conversation_id: str | None = None
    ) -> RepositoryTransactionResult:
        try:
            with self.transaction() as cursor:
                topic_id = self.conversation_topic_for_write(
                    cursor,
                    user_id=user_id,
                    title=topic_title,
                    parent_hop_id=parent_hop_id,
                    conversation_id=conversation_id,
                )
                hop_write = self.append_conversation_hop(
                    cursor,
                    topic_id=topic_id,
                    user_id=user_id,
                    intent=intent,
                    raw_user_query=raw_user_query,
                    rewritten_user_query=rewritten_user_query,
                    raw_response=response_text,
                    response_type=response_type,
                    parent_hop_id=parent_hop_id,
                    entities=(
                        {"conversation_id": conversation_id}
                        if conversation_id
                        else None
                    ),
                )
                result = RepositoryActionResult(
                    action_id=new_id(),
                    action_type="noop",
                    status="skipped",
                    domain_entity_type="none",
                    audit_hop_id=hop_write.hop_id,
                    indexing_outbox_ids=(hop_write.outbox_job_id,),
                    user_safe_summary="No action was necessary.",
                    reason_summary="The branch detected a safe no-op condition.",
                )
                return RepositoryTransactionResult(
                    committed=True,
                    results=(result,),
                    audit_topic_id=hop_write.topic_id,
                    audit_hop_id=hop_write.hop_id,
                    indexing_outbox_ids=(hop_write.outbox_job_id,),
                )
        except Exception:
            return RepositoryTransactionResult(
                committed=False,
                results=(),
                error_type="RepositoryTransactionError",
                reason_summary=(
                    "The database transaction failed and was rolled back."
                ),
            )

    def _apply_knowledge_action(
        self, cursor: Connection, *, user_id: str, action: ValidatedKnowledgeAction
    ) -> RepositoryActionResult:
        action_type = action.action
        if action_type is KnowledgeAction.ADD:
            topic_id, chunk_id, outbox_job_id = self.add_knowledge_chunk(
                cursor,
                user_id=user_id,
                title=action.topic_title or "Knowledge",
                text=action.knowledge_text or action.new_text or "",
                source_id=None,
                metadata=None,
            )
            was_already_known = outbox_job_id is None
            if was_already_known:
                outbox_job_id = self.insert_outbox_job(
                    cursor,
                    entity_type=OutboxEntityType.KNOWLEDGE_CHUNK,
                    entity_id=chunk_id,
                    operation=OutboxOperation.UPSERT,
                )
            self._touch_knowledge_topic(
                cursor,
                user_id=user_id,
                knowledge_topic_id=topic_id,
            )
            return RepositoryActionResult(
                action_id=new_id(),
                action_type=action_type.value,
                status="committed",
                domain_entity_type="knowledge_chunk",
                domain_entity_id=chunk_id,
                indexing_outbox_ids=(outbox_job_id,) if outbox_job_id else (),
                user_safe_summary=(
                    "Knowledge was already known."
                    if was_already_known
                    else "Added new knowledge."
                ),
            )
        if action_type in {KnowledgeAction.DELETE, KnowledgeAction.MODIFY}:
            chunk_id = action.target_chunk_ids[0]
            target = cursor.execute(
                select(
                    knowledge_chunks.c.knowledge_topic_id,
                    knowledge_chunks.c.normalized_text,
                ).where(
                    and_(
                        knowledge_chunks.c.user_id == user_id,
                        knowledge_chunks.c.chunk_id == chunk_id,
                        knowledge_chunks.c.is_deleted == 0,
                    )
                )
            ).fetchone()
            if not target:
                raise KnowledgeConflictError(
                    "Active knowledge target was not found"
                )
            target_topic_id = str(target[0])
            if action.target_topic_ids and set(action.target_topic_ids) != {
                target_topic_id
            }:
                raise KnowledgeConflictError(
                    "Knowledge target topic no longer matches"
                )
            if action_type is KnowledgeAction.MODIFY:
                replacement_text = " ".join(
                    (action.replacement_text or action.new_text or "").split()
                )
                if not replacement_text:
                    raise KnowledgeConflictError(
                        "Knowledge replacement text is empty"
                    )
                if replacement_text == str(target[1]):
                    raise KnowledgeConflictError(
                        "Knowledge replacement already matches the active target"
                    )
                duplicate_replacement = cursor.execute(
                    select(knowledge_chunks.c.chunk_id)
                    .where(
                        and_(
                            knowledge_chunks.c.user_id == user_id,
                            knowledge_chunks.c.knowledge_topic_id
                            == target_topic_id,
                            knowledge_chunks.c.content_hash
                            == content_hash(user_id, replacement_text),
                            knowledge_chunks.c.chunk_id != chunk_id,
                        )
                    )
                    .limit(1)
                ).fetchone()
                if duplicate_replacement:
                    raise KnowledgeConflictError(
                        "Knowledge replacement already exists in the target topic"
                    )
            expected_version = action.observed_versions.get(chunk_id)
            del_outbox_job_id = self.soft_delete_knowledge_chunk(
                cursor,
                user_id=user_id,
                chunk_id=chunk_id,
                expected_version=expected_version,
                change_reason=action.reason_summary or action.action.value,
                modified_by_user_query=action.target_description,
            )
            if action_type is KnowledgeAction.MODIFY:
                _, new_chunk_id, add_outbox_job_id = self.add_knowledge_chunk(
                    cursor,
                    user_id=user_id,
                    title=action.topic_title or "Knowledge",
                    text=action.replacement_text or action.new_text or "",
                    source_id=None,
                    metadata=None,
                    replaces_chunk_id=chunk_id,
                    change_reason=action.reason_summary or "modify",
                    modified_by_user_query=action.target_description,
                    knowledge_topic_id=target_topic_id,
                )
                cursor.execute(
                    update(knowledge_chunks)
                    .where(and_(knowledge_chunks.c.user_id == user_id, knowledge_chunks.c.chunk_id == chunk_id))
                    .values(replaced_by_chunk_id=new_chunk_id)
                )
                self._touch_knowledge_topic(
                    cursor,
                    user_id=user_id,
                    knowledge_topic_id=target_topic_id,
                )
                
                outbox_jobs = [del_outbox_job_id]
                if add_outbox_job_id:
                    outbox_jobs.append(add_outbox_job_id)
                    
                return RepositoryActionResult(
                    action_id=new_id(),
                    action_type=action_type.value,
                    status="committed",
                    domain_entity_type="knowledge_chunk",
                    domain_entity_id=new_chunk_id,
                    indexing_outbox_ids=tuple(outbox_jobs),
                    user_safe_summary="Modified knowledge.",
                )
            self._touch_knowledge_topic(
                cursor,
                user_id=user_id,
                knowledge_topic_id=target_topic_id,
            )
            return RepositoryActionResult(
                action_id=new_id(),
                action_type=action_type.value,
                status="committed",
                domain_entity_type="knowledge_chunk",
                domain_entity_id=chunk_id,
                indexing_outbox_ids=(del_outbox_job_id,),
                user_safe_summary="Deleted knowledge.",
            )
        raise ValueError("Unsupported knowledge action")

    def transactional_knowledge_actions(
        self,
        *,
        user_id: str,
        topic_title: str,
        raw_user_query: str,
        rewritten_user_query: str,
        response_text: str,
        actions: list[ValidatedKnowledgeAction],
        parent_hop_id: str | None = None,
        conversation_id: str | None = None,
    ) -> RepositoryTransactionResult:
        for action in actions:
            if action.validation_result != ActionValidationResult.EXECUTE:
                raise ValueError("Repository methods must receive only executable actions.")
        try:
            with self.transaction() as cursor:
                topic_id = self.conversation_topic_for_write(
                    cursor,
                    user_id=user_id,
                    title=topic_title,
                    parent_hop_id=parent_hop_id,
                    conversation_id=conversation_id,
                )
                results: list[RepositoryActionResult] = []
                outbox_jobs: list[str] = []
                knowledge_entities: list[dict[str, Any]] = []
                for action in actions:
                    result = self._apply_knowledge_action(cursor, user_id=user_id, action=action)
                    results.append(result)
                    outbox_jobs.extend(result.indexing_outbox_ids)
                    if not result.domain_entity_id:
                        raise KnowledgeConflictError(
                            "Knowledge mutation did not resolve a chunk"
                        )
                    entity_row = cursor.execute(
                        select(knowledge_chunks.c.knowledge_topic_id).where(
                            and_(
                                knowledge_chunks.c.user_id == user_id,
                                knowledge_chunks.c.chunk_id
                                == result.domain_entity_id,
                            )
                        )
                    ).fetchone()
                    if not entity_row:
                        raise KnowledgeConflictError(
                            "Knowledge mutation chunk was not persisted"
                        )
                    knowledge_entities.append(
                        {
                            "entity_type": "knowledge_chunk",
                            "action": action.action.value,
                            "knowledge_topic_id": str(entity_row[0]),
                            "knowledge_chunk_id": result.domain_entity_id,
                            "target_chunk_ids": list(action.target_chunk_ids),
                            "status": result.status,
                        }
                    )
                hop = self.append_conversation_hop(
                    cursor,
                    topic_id=topic_id,
                    user_id=user_id,
                    intent="knowledge_facts",
                    raw_user_query=raw_user_query,
                    rewritten_user_query=rewritten_user_query,
                    raw_response=response_text,
                    response_type="knowledge_action",
                    parent_hop_id=parent_hop_id,
                    entities={
                        "knowledge": knowledge_entities,
                        **(
                            {"conversation_id": conversation_id}
                            if conversation_id
                            else {}
                        ),
                    },
                )
                outbox_jobs.append(hop.outbox_job_id)
                updated_results = []
                for r in results:
                    updated_results.append(
                        RepositoryActionResult(
                            action_id=r.action_id,
                            action_type=r.action_type,
                            status=r.status,
                            domain_entity_type=r.domain_entity_type,
                            domain_entity_id=r.domain_entity_id,
                            audit_hop_id=hop.hop_id,
                            indexing_outbox_ids=r.indexing_outbox_ids,
                            user_safe_summary=r.user_safe_summary,
                            reason_summary=r.reason_summary,
                        )
                    )
                return RepositoryTransactionResult(
                    committed=True,
                    results=tuple(updated_results),
                    audit_topic_id=hop.topic_id,
                    audit_hop_id=hop.hop_id,
                    indexing_outbox_ids=tuple(outbox_jobs),
                )
        except RepositoryConflictError as exc:
            from .errors import safe_repository_reason
            return RepositoryTransactionResult(
                committed=False,
                results=(),
                audit_hop_id=None,
                indexing_outbox_ids=(),
                error_type="optimistic_concurrency_error",
                reason_summary=safe_repository_reason(exc),
            )
        except Exception:
            return RepositoryTransactionResult(
                committed=False,
                results=(),
                audit_hop_id=None,
                indexing_outbox_ids=(),
                error_type="RepositoryTransactionError",
                reason_summary=(
                    "The database transaction failed and was rolled back."
                ),
            )

    def transactional_reminder_actions(
        self,
        *,
        user_id: str,
        topic_title: str,
        raw_user_query: str,
        rewritten_user_query: str,
        response_text: str,
        actions: list[ValidatedReminderAction],
        parent_hop_id: str | None = None,
        conversation_id: str | None = None,
    ) -> RepositoryTransactionResult:
        for action in actions:
            if action.validation_result != ActionValidationResult.EXECUTE:
                raise ValueError("Repository methods must receive only executable actions.")
        try:
            with self.transaction() as cursor:
                topic_id = self.conversation_topic_for_write(
                    cursor,
                    user_id=user_id,
                    title=topic_title,
                    parent_hop_id=parent_hop_id,
                    conversation_id=conversation_id,
                )
                results: list[RepositoryActionResult] = []
                reminder_entities: list[dict[str, str]] = []
                audit_hop_id = new_id()
                hop_write = self.append_conversation_hop(
                    cursor,
                    topic_id=topic_id,
                    user_id=user_id,
                    intent=Intent.REMINDER.value,
                    raw_user_query=raw_user_query,
                    rewritten_user_query=rewritten_user_query,
                    raw_response=response_text,
                    response_type=ResponseType.REMINDER_ACTION.value,
                    entities={
                        "reminders": reminder_entities,
                        **(
                            {"conversation_id": conversation_id}
                            if conversation_id
                            else {}
                        ),
                    },
                    hop_id=audit_hop_id,
                    parent_hop_id=parent_hop_id,
                )
                for action in actions:
                    result = self._apply_reminder_action(
                        cursor,
                        user_id=user_id,
                        source_topic_id=topic_id,
                        action=action,
                        audit_hop_id=audit_hop_id,
                    )
                    results.append(result)
                    if result.domain_entity_id:
                        reminder_entities.append(
                            {
                                "entity_type": "reminder",
                                "reminder_id": result.domain_entity_id,
                                "subject": str(action.subject or action.replacement_subject or action.reminder_summary or ""),
                            }
                        )

                cursor.execute(
                    update(conversation_hops)
                    .where(
                        and_(
                            conversation_hops.c.hop_id == hop_write.hop_id,
                            conversation_hops.c.user_id == user_id,
                        )
                    )
                    .values(
                        entities_json=json.dumps(
                            {
                                "reminders": reminder_entities,
                                **(
                                    {"conversation_id": conversation_id}
                                    if conversation_id
                                    else {}
                                ),
                            }
                        )
                    )
                )
                
                updated_results = []
                for r in results:
                    updated_results.append(
                        RepositoryActionResult(
                            action_id=r.action_id,
                            action_type=r.action_type,
                            status=r.status,
                            domain_entity_type=r.domain_entity_type,
                            domain_entity_id=r.domain_entity_id,
                            audit_hop_id=hop_write.hop_id,
                            indexing_outbox_ids=r.indexing_outbox_ids,
                            user_safe_summary=r.user_safe_summary,
                            reason_summary=r.reason_summary,
                        )
                    )
                    
                return RepositoryTransactionResult(
                    committed=True,
                    results=tuple(updated_results),
                    audit_topic_id=hop_write.topic_id,
                    audit_hop_id=hop_write.hop_id,
                    indexing_outbox_ids=(hop_write.outbox_job_id,),
                )
        except RepositoryConflictError as exc:
            from .errors import safe_repository_reason
            return RepositoryTransactionResult(
                committed=False,
                results=(),
                audit_hop_id=None,
                indexing_outbox_ids=(),
                error_type=type(exc).__name__,
                reason_summary=safe_repository_reason(exc),
            )
        except Exception:
            return RepositoryTransactionResult(
                committed=False,
                results=(),
                audit_hop_id=None,
                indexing_outbox_ids=(),
                error_type="RepositoryTransactionError",
                reason_summary="The database transaction failed and was rolled back.",
            )

    def _apply_reminder_action(
        self,
        cursor: Connection,
        *,
        user_id: str,
        source_topic_id: str,
        action: ValidatedReminderAction,
        audit_hop_id: str,
    ) -> RepositoryActionResult:
        action_type = action.action

        def preserve_explicit_notification_time(reminder_id: str) -> None:
            if action.timing_plan_required:
                return
            result = cursor.execute(
                update(reminders)
                .where(
                    and_(
                        reminders.c.user_id == user_id,
                        reminders.c.reminder_id == reminder_id,
                    )
                )
                .values(
                    timing_plan_status="planned",
                    timing_planned_at=now_iso(),
                    timing_plan_reason=(
                        "Explicit notification time preserved from validated reminder mutation."
                    ),
                )
            )
            if result.rowcount != 1:
                raise ReminderConflictError(
                    "Explicit reminder timing state could not be preserved"
                )

        if action_type is ReminderAction.ADD:
            if not action.reminder_time:
                raise RepositoryValidationError("Reminder time is required")
            reminder_id = self.add_reminder(
                cursor,
                user_id=user_id,
                source_topic_id=source_topic_id,
                source_hop_id=audit_hop_id,
                reminder_time=action.reminder_time.isoformat(),
                event_time=(
                    action.event_time
                    or (action.reminder_time if action.timing_plan_required else None)
                ).isoformat()
                if (
                    action.event_time
                    or (action.reminder_time if action.timing_plan_required else None)
                )
                else None,
                raw_reminder=action.raw_reminder or "",
                reminder_summary=action.reminder_summary or "",
                subject=action.subject or "",
                supporting_question=action.supporting_question,
                supporting_response=action.supporting_response,
                user_timezone=action.user_timezone or "UTC",
                original_time_text=action.original_time_text,
                recurrence_rule=action.recurrence_rule,
                recurrence_timezone=action.recurrence_timezone or action.user_timezone,
                next_fire_time=action.next_fire_time.isoformat() if action.next_fire_time else (action.reminder_time.isoformat() if action.recurrence_rule and action.reminder_time else None),
                parent_recurring_reminder_id=action.parent_recurring_reminder_id,
            )
            preserve_explicit_notification_time(reminder_id)
            return RepositoryActionResult(
                action_id=new_id(),
                action_type=action_type.value,
                status="committed",
                domain_entity_type="reminder",
                domain_entity_id=reminder_id,
                indexing_outbox_ids=(),
                user_safe_summary=(
                    f"Added reminder '{action.subject}'. "
                    + (
                        "Timing will be finalized by autoscan before it can notify you."
                        if action.timing_plan_required
                        else "The validated notification time was preserved."
                    )
                ),
            )

        if not action.target_reminder_ids:
            raise RepositoryValidationError("Reminder target id is required")

        reminder_id = action.target_reminder_ids[0]
        if action_type is ReminderAction.MODIFY:
            original_source = cursor.execute(
                select(reminders.c.source_topic_id, reminders.c.source_hop_id).where(
                    and_(
                        reminders.c.user_id == user_id,
                        reminders.c.reminder_id == reminder_id,
                    )
                )
            ).fetchone()
            if not original_source:
                raise ReminderConflictError("Reminder source binding was not found")
            self.update_reminder_status(
                cursor,
                user_id=user_id,
                reminder_id=reminder_id,
                status=ReminderStatus.CANCELLED.value,
                expected_version=action.observed_version,
                expected_status=action.observed_status,
            )
            replacement_summary = (
                action.replacement_summary
                if action.replacement_summary is not None
                else action.reminder_summary
            )
            replacement_recurrence_rule = (
                action.replacement_recurrence_rule
                if action.replacement_recurrence_rule is not None
                else action.recurrence_rule
            )
            replacement_recurrence_timezone = (
                action.replacement_recurrence_timezone
                if action.replacement_recurrence_timezone is not None
                else action.recurrence_timezone or action.user_timezone
            )
            replacement_time = action.replacement_time or action.reminder_time or action.observed_reminder_time
            if not replacement_time:
                raise RepositoryValidationError("Replacement reminder time is required")
            new_reminder_id = self.add_reminder(
                cursor,
                user_id=user_id,
                source_topic_id=original_source[0] or source_topic_id,
                source_hop_id=original_source[1] or audit_hop_id,
                reminder_time=replacement_time.isoformat(),
                event_time=(
                    action.event_time
                    or (replacement_time if action.timing_plan_required else None)
                ).isoformat()
                if (
                    action.event_time
                    or (replacement_time if action.timing_plan_required else None)
                )
                else None,
                raw_reminder=action.raw_reminder or "",
                reminder_summary=replacement_summary or "",
                subject=action.replacement_subject or action.subject or "",
                supporting_question=action.supporting_question,
                supporting_response=action.supporting_response,
                user_timezone=action.user_timezone or "UTC",
                original_time_text=action.original_time_text,
                recurrence_rule=replacement_recurrence_rule,
                recurrence_timezone=replacement_recurrence_timezone,
                next_fire_time=action.next_fire_time.isoformat() if action.next_fire_time else (replacement_time.isoformat() if replacement_recurrence_rule else None),
                parent_recurring_reminder_id=reminder_id,
            )
            preserve_explicit_notification_time(new_reminder_id)
            return RepositoryActionResult(
                action_id=new_id(),
                action_type=action_type.value,
                status="committed",
                domain_entity_type="reminder",
                domain_entity_id=new_reminder_id,
                indexing_outbox_ids=(),
                user_safe_summary=(
                    f"Modified reminder '{action.replacement_subject or action.subject}'. "
                    + (
                        "Timing will be recalculated by autoscan."
                        if action.timing_plan_required
                        else "The validated notification time was preserved."
                    )
                ),
            )

        status_by_action = {
            ReminderAction.TURN_ON: ReminderStatus.SCHEDULED.value,
            ReminderAction.TURN_OFF: ReminderStatus.CANCELLED.value,
            ReminderAction.DELETE: ReminderStatus.DISMISSED.value,
        }
        if action_type not in status_by_action:
            raise ValueError("Unsupported reminder action")
        new_status = status_by_action[action_type]
        if action_type is ReminderAction.TURN_ON:
            result = cursor.execute(
                update(reminders)
                .where(and_(
                    reminders.c.user_id == user_id,
                    reminders.c.reminder_id == reminder_id,
                    reminders.c.version == action.observed_version,
                    reminders.c.status == action.observed_status,
                ))
                .values(
                    status=ReminderStatus.SCHEDULED.value,
                    reminder_time=func.coalesce(reminders.c.event_time, reminders.c.reminder_time),
                    next_fire_time=case(
                        (reminders.c.recurrence_rule.is_not(None), func.coalesce(reminders.c.event_time, reminders.c.reminder_time)),
                        else_=None,
                    ),
                    timing_plan_status="pending", timing_planned_at=None,
                    timing_plan_reason=None, updated_at=now_iso(),
                    version=reminders.c.version + 1,
                )
            )
            if result.rowcount != 1:
                raise ReminderConflictError("Reminder update failed ownership, version, or status validation")
        else:
            self.update_reminder_status(
                cursor,
                user_id=user_id,
                reminder_id=reminder_id,
                status=new_status,
                expected_version=action.observed_version,
                expected_status=action.observed_status,
            )
        return RepositoryActionResult(
            action_id=new_id(),
            action_type=action_type.value,
            status="committed",
            domain_entity_type="reminder",
            domain_entity_id=reminder_id,
            indexing_outbox_ids=(),
            user_safe_summary=(
                f"Reminder '{action.subject or reminder_id}' is scheduled again; its timing will be recalculated by autoscan."
                if action_type is ReminderAction.TURN_ON
                else f"Reminder '{action.subject or reminder_id}' is now {new_status}."
            ),
        )

    def list_reminder_candidates(
        self, user_id: str, statuses: tuple[str, ...], time_window: tuple[datetime, datetime] | None, limit: int
    ) -> list[ReminderCandidateSummary]:
        stmt = select(
            reminders.c.reminder_id,
            reminders.c.subject,
            reminders.c.reminder_summary,
            reminders.c.raw_reminder,
            reminders.c.reminder_time,
            reminders.c.status,
            reminders.c.created_at,
            reminders.c.updated_at,
            reminders.c.version
        ).where(
            and_(
                reminders.c.user_id == user_id,
                reminders.c.status.in_(statuses)
            )
        )
        if time_window:
            stmt = stmt.where(
                and_(
                    reminders.c.reminder_time >= time_window[0].isoformat(),
                    reminders.c.reminder_time <= time_window[1].isoformat()
                )
            )
        stmt = stmt.order_by(reminders.c.reminder_time).limit(limit)
        
        with self.engine.connect() as conn:
            rows = conn.execute(stmt).fetchall()
            return [
                ReminderCandidateSummary(
                    reminder_id=row[0],
                    subject=row[1],
                    reminder_summary=row[2],
                    raw_reminder=row[3],
                    reminder_time=datetime.fromisoformat(row[4]) if row[4] else None,
                    status=row[5],
                    created_at=datetime.fromisoformat(row[6]) if row[6] else datetime.now(timezone.utc),
                    updated_at=datetime.fromisoformat(row[7]) if row[7] else None,
                    version=row[8],
                    is_deleted=False,
                ) for row in rows
            ]

    def list_notifications(
        self, *, user_id: str, include_deleted: bool = False
    ) -> list[dict[str, Any]]:
        stmt = select(
            reminder_notifications.c.notification_id,
            reminder_notifications.c.ui_status,
            reminder_notifications.c.delivery_status,
            reminder_notifications.c.delivery_attempts,
            reminder_notifications.c.last_delivery_error,
            reminder_notifications.c.sent_at,
            reminder_notifications.c.fire_time,
            reminder_notifications.c.created_at,
            reminder_notifications.c.read_at,
            reminder_notifications.c.deleted_at,
            reminders.c.reminder_id,
            reminders.c.subject,
            reminders.c.reminder_time,
            reminders.c.status,
            reminders.c.reminder_summary,
        ).select_from(
            reminder_notifications.join(
                reminders, reminder_notifications.c.reminder_id == reminders.c.reminder_id
            )
        ).where(reminder_notifications.c.user_id == user_id)
        
        if not include_deleted:
            stmt = stmt.where(reminder_notifications.c.ui_status != 'deleted')
            
        stmt = stmt.order_by(
            func.coalesce(
                reminder_notifications.c.fire_time,
                reminders.c.reminder_time,
                reminder_notifications.c.created_at,
            ).desc(),
            reminder_notifications.c.created_at.desc(),
        )
        
        with self.engine.connect() as conn:
            rows = conn.execute(stmt).fetchall()
            return [
                {
                    "notification_id": row[0],
                    "ui_status": row[1],
                    "delivery_status": row[2],
                    "delivery_attempts": row[3],
                    "last_delivery_error": row[4],
                    "sent_at": row[5],
                    "fire_time": row[6],
                    "created_at": row[7],
                    "read_at": row[8],
                    "deleted_at": row[9],
                    "reminder_id": row[10],
                    "subject": row[11],
                    "reminder_time": row[12],
                    "reminder_status": row[13],
                    "reminder_summary": row[14],
                } for row in rows
            ]

    def update_notification_ui_status(
        self, *, user_id: str, notification_id: str, ui_status: str
    ) -> dict[str, Any]:
        if ui_status not in {"unread", "read", "deleted"}:
            raise ValueError("Invalid notification UI status")
        timestamp = now_iso()
        values: dict[str, Any] = {"ui_status": ui_status}
        if ui_status == "read":
            values.update(read_at=timestamp, deleted_at=None)
        elif ui_status == "unread":
            # An unread notification must not retain an old read timestamp.
            values.update(read_at=None, deleted_at=None)
        else:
            values["deleted_at"] = timestamp
        with self.transaction() as cursor:
            stmt = update(reminder_notifications).where(
                and_(
                    reminder_notifications.c.user_id == user_id,
                    reminder_notifications.c.notification_id == notification_id
                )
            ).values(**values).returning(
                reminder_notifications.c.notification_id,
                reminder_notifications.c.reminder_id,
                reminder_notifications.c.user_id,
                reminder_notifications.c.ui_status,
                reminder_notifications.c.delivery_status,
                reminder_notifications.c.delivery_attempts,
                reminder_notifications.c.last_delivery_error,
                reminder_notifications.c.sent_at,
                reminder_notifications.c.fire_time,
                reminder_notifications.c.created_at,
                reminder_notifications.c.read_at,
                reminder_notifications.c.deleted_at,
            )
            
            row = cursor.execute(stmt).fetchone()
            if not row:
                raise ValueError("Notification not found")
            return {
                "notification_id": row[0],
                "reminder_id": row[1],
                "user_id": row[2],
                "ui_status": row[3],
                "delivery_status": row[4],
                "delivery_attempts": row[5],
                "last_delivery_error": row[6],
                "sent_at": row[7],
                "fire_time": row[8],
                "created_at": row[9],
                "read_at": row[10],
                "deleted_at": row[11],
            }

    def update_all_notification_ui_status(self, *, user_id: str, ui_status: str) -> int:
        """Atomically mark this user's visible notifications read or unread."""
        if ui_status not in {"unread", "read"}:
            raise ValueError("Bulk notification status must be read or unread")
        values: dict[str, Any]
        if ui_status == "read":
            values = {"ui_status": "read", "read_at": now_iso(), "deleted_at": None}
        else:
            values = {"ui_status": "unread", "read_at": None, "deleted_at": None}
        with self.transaction() as cursor:
            result = cursor.execute(
                update(reminder_notifications)
                .where(
                    and_(
                        reminder_notifications.c.user_id == user_id,
                        reminder_notifications.c.ui_status != "deleted",
                        reminder_notifications.c.ui_status != ui_status,
                    )
                )
                .values(**values)
            )
            return int(result.rowcount)

    def mark_notification_delivery_sent(
        self, *, user_id: str, notification_id: str
    ) -> dict[str, Any]:
        with self.transaction() as cursor:
            stmt = update(reminder_notifications).where(
                and_(
                    reminder_notifications.c.user_id == user_id,
                    reminder_notifications.c.notification_id == notification_id,
                )
            ).values(
                delivery_status=NotificationDeliveryStatus.SENT.value,
                sent_at=now_iso(),
                last_delivery_error=None,
            ).returning(reminder_notifications)
            row = cursor.execute(stmt).fetchone()
            if not row:
                raise ValueError("Notification not found")
            return dict(row._mapping)

    def mark_notification_delivery_failed(
        self, *, user_id: str, notification_id: str, error_message: str, retrying: bool = False
    ) -> dict[str, Any]:
        status = NotificationDeliveryStatus.RETRYING.value if retrying else NotificationDeliveryStatus.FAILED.value
        with self.transaction() as cursor:
            stmt = update(reminder_notifications).where(
                and_(
                    reminder_notifications.c.user_id == user_id,
                    reminder_notifications.c.notification_id == notification_id,
                )
            ).values(
                delivery_status=status,
                delivery_attempts=reminder_notifications.c.delivery_attempts + 1,
                last_delivery_error=error_message,
            ).returning(reminder_notifications)
            row = cursor.execute(stmt).fetchone()
            if not row:
                raise ValueError("Notification not found")
            return dict(row._mapping)

    def claim_idempotency_key(
        self, *, user_id: str, idempotency_key: str, payload_hash: str
    ) -> IdempotencyClaimResult:
        with self.transaction() as cursor:
            request_id = new_id()
            timestamp = now_iso()
            values = {
                "request_id": request_id,
                "user_id": user_id,
                "idempotency_key": idempotency_key,
                "payload_hash": payload_hash,
                "status": MutationRequestStatus.IN_PROGRESS.value,
                "created_at": timestamp,
                "updated_at": timestamp,
            }
            dialect_insert = (
                sqlite_insert(mutation_requests)
                if cursor.dialect.name == "sqlite"
                else postgresql_insert(mutation_requests)
            )
            inserted = cursor.execute(
                dialect_insert.values(**values).on_conflict_do_nothing(
                    index_elements=[
                        mutation_requests.c.user_id,
                        mutation_requests.c.idempotency_key,
                    ]
                )
            )
            if inserted.rowcount == 1:
                return IdempotencyClaimResult(
                    status="started",
                    request_id=request_id,
                )
            row = cursor.execute(
                select(
                    mutation_requests.c.request_id,
                    mutation_requests.c.payload_hash,
                    mutation_requests.c.status,
                    mutation_requests.c.stored_response_json,
                ).where(
                    and_(
                        mutation_requests.c.user_id == user_id,
                        mutation_requests.c.idempotency_key == idempotency_key,
                    )
                ).with_for_update()
            ).fetchone()
            if row:
                if row[1] != payload_hash:
                    return IdempotencyClaimResult(status="conflict", request_id=row[0], reason="idempotency_conflict")
                if row[2] == MutationRequestStatus.COMPLETED.value:
                    return IdempotencyClaimResult(status="replay", request_id=row[0], stored_response_json=row[3])
                if row[2] == MutationRequestStatus.IN_PROGRESS.value:
                    return IdempotencyClaimResult(status="in_progress", request_id=row[0], reason="request_in_progress")
                retry_claim = cursor.execute(
                    update(mutation_requests)
                    .where(
                        and_(
                            mutation_requests.c.request_id == row[0],
                            mutation_requests.c.status
                            == MutationRequestStatus.FAILED.value,
                        )
                    )
                    .values(
                        status=MutationRequestStatus.IN_PROGRESS.value,
                        updated_at=now_iso(),
                    )
                )
                if retry_claim.rowcount != 1:
                    return IdempotencyClaimResult(
                        status="in_progress",
                        request_id=row[0],
                        reason="request_in_progress",
                    )
                return IdempotencyClaimResult(status="failed_retry", request_id=row[0])
            # The unique row was inserted by another transaction and must be
            # visible after the conflict. A missing row indicates repository
            # corruption rather than permission to execute twice.
            raise RuntimeError("Idempotency key conflict row was unavailable")

    def complete_idempotency_request(self, *, request_id: str, stored_response_json: str) -> None:
        with self.transaction() as cursor:
            cursor.execute(
                update(mutation_requests).where(mutation_requests.c.request_id == request_id).values(
                    status=MutationRequestStatus.COMPLETED.value,
                    stored_response_json=stored_response_json,
                    updated_at=now_iso(),
                )
            )

    def fail_idempotency_request(self, *, request_id: str, error_message: str | None = None) -> None:
        with self.transaction() as cursor:
            cursor.execute(
                update(mutation_requests).where(
                    and_(
                        mutation_requests.c.request_id == request_id,
                        mutation_requests.c.status
                        != MutationRequestStatus.COMPLETED.value,
                    )
                ).values(
                    status=MutationRequestStatus.FAILED.value,
                    updated_at=now_iso(),
                )
            )

    def create_pending_confirmation(
        self,
        *,
        user_id: str,
        action_type: str,
        target_entity_type: str,
        target_entity_id: str | None,
        proposed_action: dict[str, Any],
        target_snapshot: dict[str, Any],
        expires_at: str,
    ) -> dict[str, Any]:
        token = new_id()
        timestamp = now_iso()
        with self.transaction() as cursor:
            cursor.execute(
                insert(pending_action_confirmations).values(
                    confirmation_token=token,
                    user_id=user_id,
                    action_type=action_type,
                    target_entity_type=target_entity_type,
                    target_entity_id=target_entity_id,
                    proposed_action_json=json.dumps(proposed_action, default=str),
                    target_snapshot_json=json.dumps(target_snapshot, default=str),
                    expires_at=expires_at,
                    status=ConfirmationStatus.PENDING.value,
                    created_at=timestamp,
                )
            )
        return {
            "confirmation_token": token,
            "action_type": action_type,
            "target_entity_type": target_entity_type,
            "target_entity_id": target_entity_id,
            "expires_at": expires_at,
            "status": ConfirmationStatus.PENDING.value,
        }

    def load_pending_confirmation(
        self, *, user_id: str, confirmation_token: str, now_value: str
    ) -> dict[str, Any]:
        with self.engine.connect() as conn:
            row = conn.execute(
                select(pending_action_confirmations).where(
                    and_(
                        pending_action_confirmations.c.user_id == user_id,
                        pending_action_confirmations.c.confirmation_token == confirmation_token,
                    )
                )
            ).fetchone()
        if not row:
            raise ValueError("Confirmation not found for user")
        payload = dict(row._mapping)
        if payload["status"] != ConfirmationStatus.PENDING.value:
            raise ValueError("Confirmation is not pending")
        if payload["expires_at"] <= now_value:
            with self.transaction() as cursor:
                cursor.execute(
                    update(pending_action_confirmations)
                    .where(pending_action_confirmations.c.confirmation_token == confirmation_token)
                    .values(status=ConfirmationStatus.EXPIRED.value)
                )
            raise ValueError("Confirmation has expired")
        payload["proposed_action"] = json.loads(payload["proposed_action_json"])
        payload["target_snapshot"] = json.loads(payload["target_snapshot_json"])
        return payload

    def mark_confirmation_confirmed(self, *, user_id: str, confirmation_token: str) -> None:
        with self.transaction() as cursor:
            result = cursor.execute(
                update(pending_action_confirmations).where(
                    and_(
                        pending_action_confirmations.c.user_id == user_id,
                        pending_action_confirmations.c.confirmation_token == confirmation_token,
                        pending_action_confirmations.c.status == ConfirmationStatus.PENDING.value,
                    )
                ).values(
                    status=ConfirmationStatus.CONFIRMED.value,
                    confirmed_at=now_iso(),
                )
            )
            if result.rowcount != 1:
                raise ValueError("Confirmation could not be confirmed")

    def list_reminders(
        self, *, user_id: str, status: str | None = None, from_time: str | None = None, to_time: str | None = None
    ) -> list[dict[str, Any]]:
        stmt = select(reminders).where(reminders.c.user_id == user_id)
        if status:
            stmt = stmt.where(reminders.c.status == status)
        if from_time:
            stmt = stmt.where(reminders.c.reminder_time >= from_time)
        if to_time:
            stmt = stmt.where(reminders.c.reminder_time <= to_time)
            
        stmt = stmt.order_by(reminders.c.reminder_time)
        
        with self.engine.connect() as conn:
            rows = conn.execute(stmt).fetchall()
            return [dict(r._mapping) for r in rows]

    def append_reminder_reply(
        self, *, user_id: str, reminder_id: str, notification_id: str, reply_text: str, response_text: str
    ) -> HopWrite:
        with self.transaction() as cursor:
            ctx = self.load_reminder_reply_context(
                user_id=user_id, reminder_id=reminder_id, notification_id=notification_id
            )
            topic_id = ctx["topic_id"]
            if not topic_id:
                topic_id = self.ensure_topic(
                    cursor, user_id=user_id, title=f"Reminder: {ctx['subject']}"
                )
            from .reminder_reply import build_reminder_state, reminder_reply_hop_entities

            reply_hop_id = new_id()
            reminder_state = build_reminder_state(
                ctx,
                reminder_id=reminder_id,
                notification_id=notification_id,
            )
            return self.append_conversation_hop(
                cursor,
                topic_id=topic_id,
                user_id=user_id,
                intent=Intent.REMINDER.value,
                raw_user_query=reply_text,
                rewritten_user_query=reply_text,
                raw_response=response_text,
                response_type=ResponseType.REMINDER_REPLY.value,
                parent_hop_id=ctx["source_hop_id"],
                entities=reminder_reply_hop_entities(
                    reminder_state,
                    reply_hop_id=reply_hop_id,
                ),
                hop_id=reply_hop_id,
            )

    def claim_outbox_jobs(self, *, max_attempts: int, batch_size: int, retry_cutoff: str) -> list[dict[str, Any]]:
        with self.transaction() as cursor:
            stmt = update(indexing_outbox).where(
                indexing_outbox.c.job_id.in_(
                    select(indexing_outbox.c.job_id).where(
                        and_(
                            indexing_outbox.c.retry_count < max_attempts,
                            or_(
                                indexing_outbox.c.status == 'pending',
                                and_(
                                    indexing_outbox.c.status == 'failed',
                                    indexing_outbox.c.updated_at <= retry_cutoff
                                )
                            )
                        )
                    ).order_by(indexing_outbox.c.created_at).limit(batch_size)
                )
            ).values(
                status='processing',
                updated_at=now_iso()
            ).returning(
                indexing_outbox.c.job_id,
                indexing_outbox.c.entity_type,
                indexing_outbox.c.entity_id,
                indexing_outbox.c.operation
            )
            
            rows = cursor.execute(stmt).fetchall()
            return [
                {
                    "job_id": r[0],
                    "entity_type": r[1],
                    "entity_id": r[2],
                    "operation": r[3]
                } for r in rows
            ]

    def claim_outbox_jobs_by_ids(
        self,
        *,
        job_ids: list[str],
        max_attempts: int,
    ) -> list[dict[str, Any]]:
        unique_ids = list(dict.fromkeys(job_id for job_id in job_ids if job_id))
        if not unique_ids:
            return []
        with self.transaction() as cursor:
            rows = cursor.execute(
                update(indexing_outbox)
                .where(
                    and_(
                        indexing_outbox.c.job_id.in_(unique_ids),
                        indexing_outbox.c.retry_count < max_attempts,
                        indexing_outbox.c.status.in_(["pending", "failed"]),
                    )
                )
                .values(status="processing", updated_at=now_iso())
                .returning(
                    indexing_outbox.c.job_id,
                    indexing_outbox.c.entity_type,
                    indexing_outbox.c.entity_id,
                    indexing_outbox.c.operation,
                )
            ).fetchall()
            return [
                {
                    "job_id": row[0],
                    "entity_type": row[1],
                    "entity_id": row[2],
                    "operation": row[3],
                }
                for row in rows
            ]

    def get_outbox_job_statuses(
        self,
        *,
        job_ids: list[str],
    ) -> dict[str, str]:
        unique_ids = list(dict.fromkeys(job_id for job_id in job_ids if job_id))
        if not unique_ids:
            return {}
        with self.engine.connect() as conn:
            rows = conn.execute(
                select(indexing_outbox.c.job_id, indexing_outbox.c.status).where(
                    indexing_outbox.c.job_id.in_(unique_ids)
                )
            ).fetchall()
        return {str(row[0]): str(row[1]) for row in rows}

    def release_stale_processing_jobs(self, *, max_attempts: int, timeout_cutoff: str) -> None:
        with self.transaction() as cursor:
            stmt = update(indexing_outbox).where(
                and_(
                    indexing_outbox.c.status == 'processing',
                    indexing_outbox.c.updated_at < timeout_cutoff,
                    indexing_outbox.c.retry_count < max_attempts
                )
            ).values(
                status='failed',
                retry_count=indexing_outbox.c.retry_count + 1,
                error_message='Indexing job timed out while processing',
                updated_at=now_iso()
            )
            cursor.execute(stmt)

    def mark_outbox_job_completed(self, *, job_id: str) -> None:
        with self.transaction() as cursor:
            stmt = update(indexing_outbox).where(
                indexing_outbox.c.job_id == job_id
            ).values(
                status='completed',
                error_message=None,
                updated_at=now_iso()
            )
            cursor.execute(stmt)

    def mark_outbox_job_failed(self, *, job_id: str, error_message: str) -> None:
        with self.transaction() as cursor:
            stmt = update(indexing_outbox).where(
                indexing_outbox.c.job_id == job_id
            ).values(
                status='failed',
                retry_count=indexing_outbox.c.retry_count + 1,
                error_message=error_message,
                updated_at=now_iso()
            )
            cursor.execute(stmt)

    def load_outbox_entity(self, *, entity_type: str, entity_id: str) -> OutboxIndexPayload:
        with self.engine.connect() as conn:
            if entity_type == "conversation_hop":
                stmt = select(
                    conversation_hops,
                    conversation_topics.c.status.label("topic_status"),
                    conversation_topics.c.topic_summary.label("topic_summary"),
                    conversation_topics.c.state_summary.label("topic_state_summary"),
                    conversation_topics.c.entities_json.label("topic_entities_json"),
                    conversation_topics.c.last_hop_id.label("topic_last_hop_id"),
                    conversation_topics.c.updated_at.label("topic_updated_at"),
                    conversation_topics.c.version.label("topic_version"),
                ).select_from(
                    conversation_hops.join(
                        conversation_topics,
                        and_(
                            conversation_topics.c.topic_id == conversation_hops.c.topic_id,
                            conversation_topics.c.user_id == conversation_hops.c.user_id,
                        ),
                    )
                ).where(conversation_hops.c.hop_id == entity_id)
                row = conn.execute(stmt).fetchone()
                if not row:
                    raise ValueError("Conversation hop not found")
                hop = dict(row._mapping)
                if not is_indexable_conversation_hop(hop):
                    raise ValueError("Conversation hop is not indexable")
                return OutboxIndexPayload(
                    user_id=hop["user_id"],
                    entity_type=entity_type,
                    entity_id=entity_id,
                    text=serialize_conversation_hop(hop),
                    metadata=conversation_hop_embedding_metadata(hop),
                )
            elif entity_type == "knowledge_chunk":
                stmt = select(
                    knowledge_chunks.c.user_id,
                    knowledge_chunks.c.knowledge_topic_id,
                    knowledge_chunks.c.chunk_id,
                    knowledge_chunks.c.source_id,
                    knowledge_chunks.c.chunk_index,
                    knowledge_chunks.c.normalized_text,
                    knowledge_chunks.c.content_hash,
                    knowledge_chunks.c.is_deleted,
                    knowledge_chunks.c.version,
                    knowledge_chunks.c.created_at,
                    knowledge_chunks.c.updated_at,
                ).where(
                    and_(
                        knowledge_chunks.c.chunk_id == entity_id,
                        knowledge_chunks.c.is_deleted == 0
                    )
                )
                row = conn.execute(stmt).fetchone()
                if not row:
                    raise ValueError("Active knowledge chunk not found")
                if not is_indexable_knowledge_chunk({"is_deleted": row[7]}):
                    raise ValueError("Knowledge chunk is not indexable")
                metadata = {
                    "user_id": row[0],
                    "knowledge_topic_id": row[1],
                    "chunk_id": row[2],
                    "source_id": row[3] or "",
                    "chunk_index": int(row[4]),
                    "content_hash": row[6],
                    "is_deleted": bool(row[7]),
                    "version": int(row[8]),
                    "created_at": row[9],
                    "updated_at": row[10],
                }
                return OutboxIndexPayload(
                    user_id=row[0],
                    entity_type=entity_type,
                    entity_id=entity_id,
                    text=row[5],
                    metadata=metadata,
                )
            else:
                raise ValueError(f"Unknown entity type: {entity_type}")

    def hydrate_knowledge_retrieval_results(
        self, *, user_id: str, results: list[RetrievalResult]
    ) -> list[RetrievalResult]:
        ids = [r.entity_id for r in results if r.entity_type == "knowledge_chunk"]
        chunk_map = {
            str(row["chunk_id"]): row
            for row in self.get_knowledge_chunks_by_ids(user_id, ids, include_deleted=False)
        }
        hydrated: list[RetrievalResult] = []
        for result in results:
            chunk = chunk_map.get(result.entity_id)
            if not chunk:
                continue
            payload = dict(result.payload)
            payload.update(
                {
                    "user_id": chunk["user_id"],
                    "knowledge_topic_id": chunk["knowledge_topic_id"],
                    "chunk_id": chunk["chunk_id"],
                    "source_id": chunk.get("source_id"),
                    "chunk_index": chunk["chunk_index"],
                    "content_hash": chunk["content_hash"],
                    "is_deleted": bool(chunk["is_deleted"]),
                    "version": chunk["version"],
                    "created_at": chunk["created_at"],
                    "updated_at": chunk["updated_at"],
                    "text": chunk["normalized_text"] or chunk["raw_text"],
                }
            )
            hydrated.append(
                RetrievalResult(
                    entity_type=result.entity_type,
                    entity_id=result.entity_id,
                    source_store_evidence=result.source_store_evidence,
                    rerank_score=result.rerank_score,
                    confidence=result.confidence,
                    validation_status="sql_validated",
                    payload=payload,
                )
            )
        return hydrated

    def hydrate_conversation_retrieval_results(
        self, *, user_id: str, results: list[RetrievalResult]
    ) -> list[RetrievalResult]:
        ids = [r.entity_id for r in results if r.entity_type == "conversation_hop"]
        if not ids:
            return []
        with self.engine.connect() as conn:
            rows = conn.execute(
                select(
                    conversation_hops,
                    conversation_topics.c.status.label("topic_status"),
                    conversation_topics.c.topic_summary.label("topic_summary"),
                    conversation_topics.c.state_summary.label("topic_state_summary"),
                    conversation_topics.c.entities_json.label("topic_entities_json"),
                    conversation_topics.c.last_hop_id.label("topic_last_hop_id"),
                    conversation_topics.c.updated_at.label("topic_updated_at"),
                    conversation_topics.c.version.label("topic_version"),
                ).where(
                    and_(
                        conversation_hops.c.user_id == user_id,
                        conversation_hops.c.hop_id.in_(ids),
                    )
                ).select_from(
                    conversation_hops.join(
                        conversation_topics,
                        and_(
                            conversation_topics.c.topic_id == conversation_hops.c.topic_id,
                            conversation_topics.c.user_id == conversation_hops.c.user_id,
                        ),
                    )
                )
            ).fetchall()
        hop_map = {str(row._mapping["hop_id"]): dict(row._mapping) for row in rows}
        hydrated: list[RetrievalResult] = []
        for result in results:
            hop = hop_map.get(result.entity_id)
            if not hop:
                continue
            semantic_hop = conversation_hop_semantic_payload(hop)
            payload = conversation_hop_semantic_payload(result.payload)
            payload.update(semantic_hop)
            payload["text"] = serialize_conversation_hop(semantic_hop)
            hydrated.append(
                RetrievalResult(
                    entity_type=result.entity_type,
                    entity_id=result.entity_id,
                    source_store_evidence=result.source_store_evidence,
                    rerank_score=result.rerank_score,
                    confidence=result.confidence,
                    validation_status="sql_validated",
                    payload=payload,
                )
            )
        return hydrated

    def is_active_conversation_link(
        self,
        *,
        user_id: str,
        topic_id: str,
        hop_id: str,
    ) -> bool:
        """Validate a cached Last-QA link as an active branch head."""

        with self.engine.connect() as conn:
            branch_child = conversation_hops.alias("branch_child")
            row = conn.execute(
                select(conversation_hops.c.hop_id)
                .select_from(
                    conversation_hops.join(
                        conversation_topics,
                        and_(
                            conversation_topics.c.topic_id
                            == conversation_hops.c.topic_id,
                            conversation_topics.c.user_id
                            == conversation_hops.c.user_id,
                        ),
                    )
                )
                .where(
                    and_(
                        conversation_hops.c.user_id == user_id,
                        conversation_hops.c.topic_id == topic_id,
                        conversation_hops.c.hop_id == hop_id,
                        conversation_topics.c.status == "active",
                        ~select(branch_child.c.hop_id)
                        .where(
                            and_(
                                branch_child.c.user_id
                                == conversation_hops.c.user_id,
                                branch_child.c.topic_id
                                == conversation_hops.c.topic_id,
                                func.coalesce(
                                    branch_child.c.branch_id,
                                    branch_child.c.root_hop_id,
                                    branch_child.c.hop_id,
                                )
                                == func.coalesce(
                                    conversation_hops.c.branch_id,
                                    conversation_hops.c.root_hop_id,
                                    conversation_hops.c.hop_id,
                                ),
                                branch_child.c.previous_hop_id
                                == conversation_hops.c.hop_id,
                            )
                        )
                        .exists(),
                    )
                )
                .limit(1)
            ).fetchone()
        return row is not None

    def list_all_outbox_entities(self) -> list[tuple[str, str]]:
        results = []
        with self.engine.connect() as conn:
            hops = conn.execute(
                select(conversation_hops.c.hop_id)
                .select_from(
                    conversation_hops.join(
                        conversation_topics,
                        and_(
                            conversation_topics.c.topic_id == conversation_hops.c.topic_id,
                            conversation_topics.c.user_id == conversation_hops.c.user_id,
                        ),
                    )
                )
                .where(conversation_topics.c.status == "active")
                .order_by(conversation_hops.c.created_at)
            ).fetchall()
            for r in hops:
                results.append(("conversation_hop", r[0]))
                
            chunks = conn.execute(
                select(knowledge_chunks.c.chunk_id)
                .where(knowledge_chunks.c.is_deleted == 0)
                .order_by(knowledge_chunks.c.created_at)
            ).fetchall()
            for r in chunks:
                results.append(("knowledge_chunk", r[0]))
        return results
